import React, { useEffect, useMemo, useState } from "react";
import {
  adminGetCategoriesApi,
  approvePartnerApi,
  changeUserRoleApi,
  getUsersApi,
  toggleUserActiveApi,
  updatePartnerSettingsApi,
} from "../../services/api";

const ROLES = [
  { label: "Customer", value: "customer" },
  { label: "Partner", value: "partner" },
  { label: "Admin", value: "admin" },
];

const WEEK_DAYS = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

const DEFAULT_WORKING_SLOTS = WEEK_DAYS.map((day) => ({
  day,
  startTime: "09:00",
  endTime: "18:00",
  isAvailable: true,
}));

function parseCsv(value) {
  return String(value || "")
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean);
}

export default function UsersTable({ role }) {
  const [items, setItems] = useState([]);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 20,
    totalPages: 1,
    total: 0,
  });
  const [search, setSearch] = useState("");
  const [approved, setApproved] = useState("all");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const [categoryOptions, setCategoryOptions] = useState([]);

  const [partnerModalOpen, setPartnerModalOpen] = useState(false);
  const [selectedPartner, setSelectedPartner] = useState(null);
  const [savingPartner, setSavingPartner] = useState(false);

  const [partnerForm, setPartnerForm] = useState({
    isApproved: false,
    isAvailable: true,
    serviceCategories: [],
    citiesText: "",
    pincodesText: "",
    maxBookingsPerDay: 5,
    priority: 0,
    workingSlots: DEFAULT_WORKING_SLOTS,
  });

  const title =
    role === "customer"
      ? "Customers"
      : role === "partner"
      ? "Service Partners"
      : "Admin Users";

  const load = async (page = 1) => {
    try {
      setLoading(true);
      setMsg("");

      const params = {
        role,
        search,
        page,
        limit: pagination.limit,
      };

      if (role === "partner" && approved !== "all") {
        params.approved = approved;
      }

      const res = await getUsersApi(params);
      setItems(res.data.items || []);
      setPagination(
        res.data.pagination || {
          page: 1,
          limit: 20,
          totalPages: 1,
          total: 0,
        }
      );
    } catch (e) {
      setMsg(e?.response?.data?.message || "Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  const loadCategories = async () => {
    try {
      const res = await adminGetCategoriesApi();
      const all = res?.data?.categories || [];
      const activeOnly = all.filter((c) => c?.isActive !== false);
      setCategoryOptions(activeOnly);
    } catch (e) {
      console.error("Failed to load categories", e);
    }
  };

  useEffect(() => {
    load(1);
    if (role === "partner") {
      loadCategories();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role, approved]);

  const toggleActive = async (id) => {
    try {
      const res = await toggleUserActiveApi(id);
      const updated = res.data.user;
      setItems((prev) => prev.map((u) => (u._id === id ? updated : u)));
    } catch (e) {
      alert(e?.response?.data?.message || "Failed to update user");
    }
  };

  const changeRole = async (id, newRole) => {
    const ok = window.confirm(`Change role to "${newRole}"?`);
    if (!ok) return;

    try {
      const res = await changeUserRoleApi(id, newRole);
      const updated = res.data.user;

      setItems((prev) => prev.filter((u) => u._id !== id));
      setMsg(`✅ Role updated for ${updated.email}`);
    } catch (e) {
      alert(e?.response?.data?.message || "Failed to change role");
    }
  };

  const approvePartner = async (id) => {
    try {
      const res = await approvePartnerApi(id);
      const updated = res.data.user;
      setItems((prev) => prev.map((u) => (u._id === id ? updated : u)));
    } catch (e) {
      alert(e?.response?.data?.message || "Failed to approve partner");
    }
  };

  const openPartnerModal = (user) => {
    const workingSlots =
      Array.isArray(user?.partner?.workingSlots) && user.partner.workingSlots.length
        ? WEEK_DAYS.map((day) => {
            const existing = user.partner.workingSlots.find((s) => s.day === day);
            return (
              existing || {
                day,
                startTime: "09:00",
                endTime: "18:00",
                isAvailable: true,
              }
            );
          })
        : DEFAULT_WORKING_SLOTS;

    setSelectedPartner(user);
    setPartnerForm({
      isApproved: !!user?.partner?.isApproved,
      isAvailable:
        typeof user?.partner?.isAvailable === "boolean"
          ? user.partner.isAvailable
          : true,
      serviceCategories: user?.partner?.serviceCategories || [],
      citiesText: (user?.partner?.cities || []).join(", "),
      pincodesText: (user?.partner?.pincodes || []).join(", "),
      maxBookingsPerDay: user?.partner?.maxBookingsPerDay || 5,
      priority: user?.partner?.priority || 0,
      workingSlots,
    });
    setPartnerModalOpen(true);
  };

  const closePartnerModal = () => {
    setPartnerModalOpen(false);
    setSelectedPartner(null);
    setSavingPartner(false);
  };

  const updateWorkingSlot = (index, key, value) => {
    setPartnerForm((prev) => {
      const nextSlots = [...prev.workingSlots];
      nextSlots[index] = {
        ...nextSlots[index],
        [key]: value,
      };
      return { ...prev, workingSlots: nextSlots };
    });
  };

  const toggleCategorySelection = (categoryName) => {
    setPartnerForm((prev) => {
      const exists = prev.serviceCategories.includes(categoryName);

      return {
        ...prev,
        serviceCategories: exists
          ? prev.serviceCategories.filter((name) => name !== categoryName)
          : [...prev.serviceCategories, categoryName],
      };
    });
  };

  const savePartnerSettings = async () => {
    if (!selectedPartner?._id) return;

    try {
      setSavingPartner(true);

      const payload = {
        isApproved: !!partnerForm.isApproved,
        isAvailable: !!partnerForm.isAvailable,
        serviceCategories: partnerForm.serviceCategories,
        cities: parseCsv(partnerForm.citiesText),
        pincodes: parseCsv(partnerForm.pincodesText),
        maxBookingsPerDay: Number(partnerForm.maxBookingsPerDay || 5),
        priority: Number(partnerForm.priority || 0),
        workingSlots: partnerForm.workingSlots.map((slot) => ({
          day: slot.day,
          startTime: slot.startTime || "09:00",
          endTime: slot.endTime || "18:00",
          isAvailable: !!slot.isAvailable,
        })),
      };

      const res = await updatePartnerSettingsApi(selectedPartner._id, payload);
      const updated = res.data.user;

      setItems((prev) => prev.map((u) => (u._id === updated._id ? updated : u)));
      setMsg(`✅ Partner settings updated for ${updated.email}`);
      closePartnerModal();
    } catch (e) {
      alert(e?.response?.data?.message || "Failed to update partner settings");
    } finally {
      setSavingPartner(false);
    }
  };

  const badge = (text, tone) => {
    const cls =
      tone === "green"
        ? "bg-green-100 text-green-700"
        : tone === "red"
        ? "bg-red-100 text-red-700"
        : tone === "yellow"
        ? "bg-yellow-100 text-yellow-700"
        : "bg-gray-100 text-gray-700";

    return (
      <span className={`px-3 py-1 rounded-full text-xs font-medium ${cls}`}>
        {text}
      </span>
    );
  };

  const partnerSummary = useMemo(() => {
    if (role !== "partner") return null;

    const total = items.length;
    const approvedCount = items.filter((u) => u?.partner?.isApproved).length;
    const availableCount = items.filter((u) => u?.partner?.isAvailable !== false).length;

    return { total, approvedCount, availableCount };
  }, [items, role]);

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-5">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
          <p className="text-sm text-gray-500 mt-1">
            Manage users, approvals, role access and partner assignment settings
          </p>
        </div>

        {loading ? <span className="text-sm text-gray-500">Loading...</span> : null}
      </div>

      {msg ? (
        <div className="mb-4 bg-white border border-gray-200 rounded-xl p-3 text-sm text-gray-700">
          {msg}
        </div>
      ) : null}

      {role === "partner" && partnerSummary ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div className="bg-white rounded-2xl shadow p-5">
            <div className="text-sm text-gray-500">Partners on this page</div>
            <div className="text-2xl font-bold mt-1">{partnerSummary.total}</div>
          </div>
          <div className="bg-white rounded-2xl shadow p-5">
            <div className="text-sm text-gray-500">Approved</div>
            <div className="text-2xl font-bold mt-1 text-green-700">
              {partnerSummary.approvedCount}
            </div>
          </div>
          <div className="bg-white rounded-2xl shadow p-5">
            <div className="text-sm text-gray-500">Available</div>
            <div className="text-2xl font-bold mt-1 text-indigo-700">
              {partnerSummary.availableCount}
            </div>
          </div>
        </div>
      ) : null}

      <div className="bg-white rounded-2xl shadow p-5 mb-4">
        <div className="flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
          <div className="flex gap-2 items-center flex-wrap">
            {role === "partner" ? (
              <>
                <button
                  onClick={() => setApproved("all")}
                  className={`px-4 py-2 rounded-full text-sm border transition ${
                    approved === "all"
                      ? "bg-indigo-600 text-white border-indigo-600"
                      : "bg-white hover:bg-gray-50"
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setApproved("true")}
                  className={`px-4 py-2 rounded-full text-sm border transition ${
                    approved === "true"
                      ? "bg-indigo-600 text-white border-indigo-600"
                      : "bg-white hover:bg-gray-50"
                  }`}
                >
                  Approved
                </button>
                <button
                  onClick={() => setApproved("false")}
                  className={`px-4 py-2 rounded-full text-sm border transition ${
                    approved === "false"
                      ? "bg-indigo-600 text-white border-indigo-600"
                      : "bg-white hover:bg-gray-50"
                  }`}
                >
                  Pending
                </button>
              </>
            ) : (
              <span className="text-sm text-gray-600">Showing role: {role}</span>
            )}
          </div>

          <div className="flex gap-2">
            <input
              className="border rounded-lg px-3 py-2 w-full md:w-80"
              placeholder="Search email / name / phone / city"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <button
              className="bg-black text-white px-4 rounded-lg"
              onClick={() => load(1)}
            >
              Search
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow overflow-hidden">
        <div className="p-4 font-semibold border-b">Users List</div>

        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-gray-600">
              <tr>
                <th className="text-left p-3">User</th>
                <th className="text-left p-3">Verified</th>
                <th className="text-left p-3">Status</th>
                {role === "partner" ? <th className="text-left p-3">Approval</th> : null}
                {role === "partner" ? <th className="text-left p-3">Assignment Info</th> : null}
                <th className="text-left p-3">Role</th>
                <th className="text-left p-3">Created</th>
                <th className="text-right p-3">Actions</th>
              </tr>
            </thead>

            <tbody>
              {items.map((u) => (
                <tr key={u._id} className="border-t align-top">
                  <td className="p-3">
                    <div className="font-medium text-gray-900">{u.email}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {u.profile?.name ? `Name: ${u.profile.name}` : ""}
                      {u.profile?.phone ? ` • Phone: ${u.profile.phone}` : ""}
                      {u.profile?.city ? ` • City: ${u.profile.city}` : ""}
                    </div>
                  </td>

                  <td className="p-3">
                    {u.isVerified
                      ? badge("Verified", "green")
                      : badge("Not Verified", "gray")}
                  </td>

                  <td className="p-3">
                    {u.isActive ? badge("Active", "green") : badge("Blocked", "red")}
                  </td>

                  {role === "partner" ? (
                    <td className="p-3">
                      {u.partner?.isApproved
                        ? badge("Approved", "green")
                        : badge("Pending", "yellow")}
                    </td>
                  ) : null}

                  {role === "partner" ? (
                    <td className="p-3">
                      <div className="text-xs text-gray-700 space-y-1 min-w-[220px]">
                        <div>
                          <span className="font-medium">Available:</span>{" "}
                          {u.partner?.isAvailable === false ? "No" : "Yes"}
                        </div>
                        <div>
                          <span className="font-medium">Categories:</span>{" "}
                          {(u.partner?.serviceCategories || []).length
                            ? u.partner.serviceCategories.join(", ")
                            : "-"}
                        </div>
                        <div>
                          <span className="font-medium">Cities:</span>{" "}
                          {(u.partner?.cities || []).length
                            ? u.partner.cities.join(", ")
                            : "-"}
                        </div>
                        <div>
                          <span className="font-medium">Pincodes:</span>{" "}
                          {(u.partner?.pincodes || []).length
                            ? u.partner.pincodes.join(", ")
                            : "-"}
                        </div>
                        <div>
                          <span className="font-medium">Max/Day:</span>{" "}
                          {u.partner?.maxBookingsPerDay || 5}
                          {"  •  "}
                          <span className="font-medium">Priority:</span>{" "}
                          {u.partner?.priority || 0}
                        </div>
                      </div>
                    </td>
                  ) : null}

                  <td className="p-3">{badge(u.role || "customer", "gray")}</td>

                  <td className="p-3 text-gray-600">
                    {u.createdAt ? new Date(u.createdAt).toLocaleString() : "-"}
                  </td>

                  <td className="p-3">
                    <div className="flex flex-col items-end gap-2 min-w-[170px]">
                      {role === "partner" && !u.partner?.isApproved ? (
                        <button
                          onClick={() => approvePartner(u._id)}
                          className="text-green-700 hover:underline text-sm"
                        >
                          Approve
                        </button>
                      ) : null}

                      {role === "partner" ? (
                        <button
                          onClick={() => openPartnerModal(u)}
                          className="text-blue-700 hover:underline text-sm"
                        >
                          Edit Partner
                        </button>
                      ) : null}

                      <button
                        onClick={() => toggleActive(u._id)}
                        className="text-indigo-600 hover:underline text-sm"
                      >
                        {u.isActive ? "Block" : "Unblock"}
                      </button>

                      <select
                        className="border rounded-lg px-2 py-1 text-xs"
                        value={u.role || "customer"}
                        onChange={(e) => changeRole(u._id, e.target.value)}
                      >
                        {ROLES.map((r) => (
                          <option key={r.value} value={r.value}>
                            {r.label}
                          </option>
                        ))}
                      </select>
                    </div>
                  </td>
                </tr>
              ))}

              {!loading && items.length === 0 ? (
                <tr>
                  <td
                    className="p-6 text-center text-gray-500"
                    colSpan={role === "partner" ? 8 : 6}
                  >
                    No users found
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>

        <div className="p-4 border-t flex items-center justify-between text-sm">
          <span className="text-gray-600">
            Page {pagination.page} / {pagination.totalPages} • Total{" "}
            {pagination.total || 0}
          </span>

          <div className="flex gap-2">
            <button
              className="border px-3 py-1 rounded-lg disabled:opacity-50"
              disabled={pagination.page <= 1}
              onClick={() => load(pagination.page - 1)}
            >
              Prev
            </button>
            <button
              className="border px-3 py-1 rounded-lg disabled:opacity-50"
              disabled={pagination.page >= pagination.totalPages}
              onClick={() => load(pagination.page + 1)}
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {partnerModalOpen && selectedPartner ? (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden">
            <div className="px-6 py-4 border-b flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Edit Partner Settings</h2>
                <p className="text-sm text-gray-500 mt-1">{selectedPartner.email}</p>
              </div>

              <button
                onClick={closePartnerModal}
                className="text-gray-500 hover:text-black text-lg"
              >
                ✕
              </button>
            </div>

            <div className="p-6 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="bg-gray-50 rounded-2xl p-4 border">
                  <h3 className="font-semibold mb-4">Basic Settings</h3>

                  <div className="space-y-4">
                    <label className="flex items-center justify-between gap-3">
                      <span className="text-sm font-medium">Approved</span>
                      <input
                        type="checkbox"
                        checked={partnerForm.isApproved}
                        onChange={(e) =>
                          setPartnerForm((prev) => ({
                            ...prev,
                            isApproved: e.target.checked,
                          }))
                        }
                      />
                    </label>

                    <label className="flex items-center justify-between gap-3">
                      <span className="text-sm font-medium">Available for assignment</span>
                      <input
                        type="checkbox"
                        checked={partnerForm.isAvailable}
                        onChange={(e) =>
                          setPartnerForm((prev) => ({
                            ...prev,
                            isAvailable: e.target.checked,
                          }))
                        }
                      />
                    </label>

                    <div>
                      <label className="block text-sm font-medium mb-1">
                        Max Bookings Per Day
                      </label>
                      <input
                        type="number"
                        min="1"
                        className="w-full border rounded-xl px-3 py-2"
                        value={partnerForm.maxBookingsPerDay}
                        onChange={(e) =>
                          setPartnerForm((prev) => ({
                            ...prev,
                            maxBookingsPerDay: e.target.value,
                          }))
                        }
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-1">Priority</label>
                      <input
                        type="number"
                        className="w-full border rounded-xl px-3 py-2"
                        value={partnerForm.priority}
                        onChange={(e) =>
                          setPartnerForm((prev) => ({
                            ...prev,
                            priority: e.target.value,
                          }))
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-2xl p-4 border">
                  <h3 className="font-semibold mb-4">Coverage & Skills</h3>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Service Categories
                      </label>

                      <div className="max-h-52 overflow-y-auto rounded-2xl border bg-white p-3 space-y-2">
                        {categoryOptions.length === 0 ? (
                          <p className="text-sm text-gray-500">No active categories found</p>
                        ) : (
                          categoryOptions.map((cat) => {
                            const checked = partnerForm.serviceCategories.includes(cat.name);

                            return (
                              <label
                                key={cat._id}
                                className="flex items-center gap-3 rounded-xl px-2 py-2 hover:bg-gray-50 cursor-pointer"
                              >
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  onChange={() => toggleCategorySelection(cat.name)}
                                />
                                <span className="text-sm text-gray-800">{cat.name}</span>
                              </label>
                            );
                          })
                        )}
                      </div>

                      <p className="text-xs text-gray-500 mt-2">
                        Select one or more real service categories
                      </p>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-1">Cities</label>
                      <input
                        type="text"
                        placeholder="Ahmedabad, Anand"
                        className="w-full border rounded-xl px-3 py-2"
                        value={partnerForm.citiesText}
                        onChange={(e) =>
                          setPartnerForm((prev) => ({
                            ...prev,
                            citiesText: e.target.value,
                          }))
                        }
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Separate by comma
                      </p>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-1">Pincodes</label>
                      <input
                        type="text"
                        placeholder="380001, 388001"
                        className="w-full border rounded-xl px-3 py-2"
                        value={partnerForm.pincodesText}
                        onChange={(e) =>
                          setPartnerForm((prev) => ({
                            ...prev,
                            pincodesText: e.target.value,
                          }))
                        }
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Separate by comma
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-5 bg-gray-50 rounded-2xl p-4 border">
                <h3 className="font-semibold mb-4">Working Schedule</h3>

                <div className="space-y-3">
                  {partnerForm.workingSlots.map((slot, index) => (
                    <div
                      key={slot.day}
                      className="grid grid-cols-1 md:grid-cols-4 gap-3 items-center border rounded-2xl bg-white p-3"
                    >
                      <div className="font-medium text-sm">{slot.day}</div>

                      <input
                        type="time"
                        className="border rounded-xl px-3 py-2"
                        value={slot.startTime}
                        onChange={(e) =>
                          updateWorkingSlot(index, "startTime", e.target.value)
                        }
                      />

                      <input
                        type="time"
                        className="border rounded-xl px-3 py-2"
                        value={slot.endTime}
                        onChange={(e) =>
                          updateWorkingSlot(index, "endTime", e.target.value)
                        }
                      />

                      <label className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={slot.isAvailable}
                          onChange={(e) =>
                            updateWorkingSlot(index, "isAvailable", e.target.checked)
                          }
                        />
                        Available
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="px-6 py-4 border-t flex justify-end gap-3 bg-white">
              <button
                onClick={closePartnerModal}
                className="px-5 py-2.5 rounded-xl border"
                disabled={savingPartner}
              >
                Cancel
              </button>

              <button
                onClick={savePartnerSettings}
                disabled={savingPartner}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white disabled:opacity-60"
              >
                {savingPartner ? "Saving..." : "Save Settings"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}