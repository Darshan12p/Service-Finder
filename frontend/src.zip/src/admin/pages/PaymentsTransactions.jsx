import { Filter } from "lucide-react";

const payments = [
  {
    user: "Annette Black",
    txnId: "8czi3qew8czi3qew",
    mobile: "+619755523240",
    service: "Classic full home cleaning (1 BHK)",
    amount: 928.41,
    method: "Credit Card",
  },
  
];

export default function PaymentsTransactions() {
  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-xl font-bold">Payments & Transactions</h1>

        <button className="flex items-center gap-2 px-4 py-2 bg-indigo-100 text-indigo-600 rounded-lg text-sm">
          <Filter size={16} />
          Filter
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-gray-500">
            <tr>
              <th className="px-4 py-3 text-left">User</th>
              <th className="px-4 py-3 text-left">Transaction ID</th>
              <th className="px-4 py-3 text-left">Mobile Number</th>
              <th className="px-4 py-3 text-left">Service</th>
              <th className="px-4 py-3 text-left">Amount</th>
              <th className="px-4 py-3 text-left">Payment Method</th>
            </tr>
          </thead>

          <tbody>
            {payments.map((p, index) => (
              <tr key={index} className="border-t">
                <td className="px-4 py-3 font-medium">{p.user}</td>
                <td className="px-4 py-3">{p.txnId}</td>
                <td className="px-4 py-3">{p.mobile}</td>
                <td className="px-4 py-3">{p.service}</td>
                <td className="px-4 py-3 text-green-600 font-semibold">
                  +${p.amount.toFixed(2)}
                </td>
                <td className="px-4 py-3">{p.method}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Footer */}
        <div className="flex justify-between items-center px-4 py-3 text-sm text-gray-500">
          <span>Rows per page: 10</span>
          <span>1–10 of 100</span>
        </div>
      </div>
    </div>
  );
}
