import React, { useEffect, useState } from "react";
import { adminDeleteReviewApi, adminGetReviewsApi } from "../../services/api";
import StarRating from "../../components/StarRating";
import Swal from "sweetalert2";
export default function Reviews() {
  const [items, setItems] = useState([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(false);

  const load = async (p = 1) => {
    try {
      setLoading(true);
      const res = await adminGetReviewsApi(p, 20);
      setItems(res.data.items || []);
      setPage(res.data.page || 1);
      setPages(res.data.pages || 1);
    } catch (e) {
      console.log("admin reviews error", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load(1);
  }, []);

  const del = async (id) => {
  const result = await Swal.fire({
    title: "Are you sure?",
    text: "This review will be permanently deleted!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#6b7280",
    confirmButtonText: "Yes, delete it!",
  });

  if (result.isConfirmed) {
    try {
      await adminDeleteReviewApi(id);

      Swal.fire({
        title: "Deleted!",
        text: "Review has been deleted.",
        icon: "success",
        timer: 1500,
        showConfirmButton: false,
      });

      load(page);
    } catch (error) {
      Swal.fire("Error", "Failed to delete review", "error");
    }
  }
};

  return (
    <div className="p-6">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Reviews</h1>
      </div>

      {loading ? (
        <p className="text-sm text-gray-500">Loading...</p>
      ) : items.length === 0 ? (
        <p className="text-sm text-gray-500">No reviews found</p>
      ) : (
        <div className="space-y-4">
          {items.map((r) => (
            <div key={r._id} className="rounded-2xl border bg-white p-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-semibold">
                    {r?.serviceId?.title || "Service"}
                  </p>
                  <p className="text-sm text-gray-600">
                    {r?.userId?.email || r?.customerEmail || "No Email"}
                  </p>
                  <p className="text-xs text-gray-500">
                    {r?.userId?.name || r?.customerName || "Unknown User"}
                  </p>
                  <p className="mt-2 text-sm">{r.comment}</p>
                  <p className="mt-2 text-xs text-gray-400">
                    {new Date(r.createdAt).toLocaleString()}
                  </p>
                </div>

                <div className="flex flex-col items-end gap-2">
                  <StarRating value={r.rating} readOnly />
                  <button
                    onClick={() => del(r._id)}
                    className="rounded-xl bg-red-600 px-3 py-2 text-xs font-semibold text-white hover:bg-red-700"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* pagination */}
      <div className="mt-6 flex items-center justify-between">
        <button
          disabled={page <= 1}
          onClick={() => load(page - 1)}
          className="rounded-lg border px-3 py-2 text-sm disabled:opacity-50"
        >
          Prev
        </button>
        <p className="text-sm text-gray-600">
          Page {page} / {pages}
        </p>
        <button
          disabled={page >= pages}
          onClick={() => load(page + 1)}
          className="rounded-lg border px-3 py-2 text-sm disabled:opacity-50"
        >
          Next
        </button>
      </div>
    </div>
  );
}
