import React, { useEffect, useMemo, useState } from "react";
import {
  adminDeleteContactMessageApi,
  adminGetContactMessagesApi,
  adminToggleContactMessageStatusApi,
} from "../../services/api";
import { Search, Trash2, CheckCircle2, Clock, X, Copy } from "lucide-react";
import Swal from "sweetalert2";
const cn = (...s) => s.filter(Boolean).join(" ");

function Chip({ tone = "gray", children }) {
  const map = {
    gray: "bg-gray-100 text-gray-700 border-gray-200",
    green: "bg-green-100 text-green-700 border-green-200",
    amber: "bg-amber-100 text-amber-700 border-amber-200",
    red: "bg-red-100 text-red-700 border-red-200",
    indigo: "bg-indigo-100 text-indigo-700 border-indigo-200",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs font-semibold",
        map[tone] || map.gray
      )}
    >
      {children}
    </span>
  );
}

function Modal({ open, title, onClose, children, footer }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-70 bg-black/40 backdrop-blur-[1px] flex items-center justify-center p-4">
      <div className="w-full max-w-2xl rounded-3xl border bg-white shadow-xl overflow-hidden">
        <div className="p-5 border-b flex items-start justify-between gap-4">
          <div>
            <h3 className="text-lg font-extrabold text-gray-900">{title}</h3>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-2xl border hover:bg-gray-50 grid place-items-center"
          >
            <X size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
        {footer ? <div className="p-5 border-t bg-gray-50/60">{footer}</div> : null}
      </div>
    </div>
  );
}

export default function ContactMessages() {
  const [items, setItems] = useState([]);
  const [status, setStatus] = useState("all");
  const [search, setSearch] = useState("");
  const [searchDebounced, setSearchDebounced] = useState("");
  const [loading, setLoading] = useState(false);

  const [busyId, setBusyId] = useState(""); // disable row action
  const [note, setNote] = useState({ type: "info", msg: "" });

  // view modal
  const [viewOpen, setViewOpen] = useState(false);
  const [viewItem, setViewItem] = useState(null);

  const showNote = (type, msg) => {
    setNote({ type, msg });
    window.clearTimeout(window.__cm_note_to);
    window.__cm_note_to = window.setTimeout(() => setNote({ type: "info", msg: "" }), 2200);
  };

  // debounce search
  useEffect(() => {
    const t = setTimeout(() => setSearchDebounced(search.trim()), 450);
    return () => clearTimeout(t);
  }, [search]);

  const load = async () => {
    setLoading(true);
    try {
      const res = await adminGetContactMessagesApi({
        status,
        search: searchDebounced,
      });
      setItems(res?.data?.items || []);
    } catch (e) {
      console.log(e);
      showNote("error", e?.response?.data?.message || "Failed to load messages");
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line
  }, [status, searchDebounced]);

  const stats = useMemo(() => {
    const total = items.length;
    const pending = items.filter((x) => x.status !== "resolved").length;
    const resolved = total - pending;
    return { total, pending, resolved };
  }, [items]);

  const toggle = async (id) => {
    try {
      setBusyId(id);
      await adminToggleContactMessageStatusApi(id);
      showNote("success", "Status updated");
      load();
    } catch (e) {
      showNote("error", e?.response?.data?.message || "Failed to update status");
    } finally {
      setBusyId("");
    }
  };

  const del = async (id) => {
  const result = await Swal.fire({
    title: "Are you sure?",
    text: "This message will be permanently deleted.",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#dc2626",
    cancelButtonColor: "#6b7280",
    confirmButtonText: "Yes, delete it!",
    cancelButtonText: "Cancel",
    reverseButtons: true,
  });

  if (!result.isConfirmed) return;

  try {
    setBusyId(id);

    Swal.fire({
      title: "Deleting...",
      text: "Please wait",
      allowOutsideClick: false,
      allowEscapeKey: false,
      didOpen: () => {
        Swal.showLoading();
      },
    });

    await adminDeleteContactMessageApi(id);
    Swal.close();

    await Swal.fire({
      title: "Deleted!",
      text: "Message deleted successfully.",
      icon: "success",
      confirmButtonColor: "#4f46e5",
      timer: 1500,
      showConfirmButton: false,
    });

    showNote("success", "Message deleted");
    load();
  } catch (e) {
    Swal.close();
    Swal.fire({
      title: "Error",
      text: e?.response?.data?.message || "Failed to delete",
      icon: "error",
      confirmButtonColor: "#dc2626",
    });
    showNote("error", e?.response?.data?.message || "Failed to delete");
  } finally {
    setBusyId("");
  }
};

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      showNote("success", "Copied");
    } catch {
      showNote("error", "Copy failed");
    }
  };

  const noteTone =
    note.type === "success"
      ? "bg-green-50 text-green-800 border-green-200"
      : note.type === "error"
      ? "bg-red-50 text-red-800 border-red-200"
      : "bg-gray-50 text-gray-800 border-gray-200";

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="mb-5 rounded-3xl border bg-linear-to-br from-indigo-50 via-white to-white p-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-3xl font-extrabold text-gray-900">Contact Messages</h1>
            <p className="text-sm text-gray-600 mt-1">
              Manage customer queries (pending / resolved).
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
            <select
              className="border rounded-2xl px-3 py-2 bg-white"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="all">All</option>
              <option value="pending">Pending</option>
              <option value="resolved">Resolved</option>
            </select>

            <div className="flex items-center gap-2 border rounded-2xl bg-white px-3 py-2 w-full sm:w-80">
              <Search size={18} className="text-gray-400" />
              <input
                className="w-full outline-none text-sm"
                placeholder="Search name / email / phone..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <button
              onClick={load}
              className="rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 font-semibold shadow-sm"
            >
              Refresh
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-2xl border bg-white p-4 shadow-sm">
            <p className="text-xs font-semibold text-gray-500">Total</p>
            <p className="text-2xl font-extrabold text-gray-900 mt-1">{stats.total}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4 shadow-sm">
            <p className="text-xs font-semibold text-gray-500">Pending</p>
            <p className="text-2xl font-extrabold text-gray-900 mt-1">{stats.pending}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4 shadow-sm">
            <p className="text-xs font-semibold text-gray-500">Resolved</p>
            <p className="text-2xl font-extrabold text-gray-900 mt-1">{stats.resolved}</p>
          </div>
        </div>

        {/* Note */}
        {note.msg ? (
          <div className={cn("mt-4 rounded-2xl border px-4 py-3 text-sm font-semibold", noteTone)}>
            {note.msg}
          </div>
        ) : null}
      </div>

      {/* Table */}
      <div className="bg-white rounded-3xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b text-sm text-gray-600">
          {loading ? "Loading..." : `Total: ${items.length}`}
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-gray-600 sticky top-0">
              <tr className="text-xs font-extrabold">
                <th className="text-left p-3">User</th>
                <th className="text-left p-3">Contact</th>
                <th className="text-left p-3">Message</th>
                <th className="text-left p-3">Status</th>
                <th className="text-right p-3">Actions</th>
              </tr>
            </thead>

            <tbody>
              {!loading && items.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-6 text-center text-gray-500">
                    No messages found
                  </td>
                </tr>
              ) : null}

              {items.map((m, idx) => {
                const isResolved = m.status === "resolved";
                const rowBusy = busyId === m._id;

                return (
                  <tr
                    key={m._id}
                    className={cn(
                      "border-t align-top",
                      idx % 2 === 0 ? "bg-white" : "bg-gray-50/40",
                      "hover:bg-indigo-50/30"
                    )}
                  >
                    <td className="p-3">
                      <div className="font-extrabold text-gray-900">
                        {m.firstName} {m.lastName}
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        {m.createdAt ? new Date(m.createdAt).toLocaleString() : ""}
                      </div>
                    </td>

                    <td className="p-3">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-gray-900">{m.email}</span>
                        {m.email ? (
                          <button
                            onClick={() => copy(m.email)}
                            className="p-2 rounded-xl border hover:bg-gray-50"
                            title="Copy email"
                          >
                            <Copy size={14} />
                          </button>
                        ) : null}
                      </div>
                      <div className="flex items-center justify-between gap-2 mt-2">
                        <span className="text-xs text-gray-500">{m.mobile}</span>
                        {m.mobile ? (
                          <button
                            onClick={() => copy(m.mobile)}
                            className="p-2 rounded-xl border hover:bg-gray-50"
                            title="Copy phone"
                          >
                            <Copy size={14} />
                          </button>
                        ) : null}
                      </div>
                    </td>

                    <td className="p-3 max-w-xl">
                      <div className="text-gray-800 line-clamp-2">{m.description}</div>
                      <button
                        onClick={() => {
                          setViewItem(m);
                          setViewOpen(true);
                        }}
                        className="mt-2 text-xs font-semibold text-indigo-600 hover:underline"
                      >
                        View full message
                      </button>
                    </td>

                    <td className="p-3">
                      <button
                        disabled={rowBusy}
                        onClick={() => toggle(m._id)}
                        className="disabled:opacity-60"
                        title="Toggle status"
                      >
                        {isResolved ? (
                          <Chip tone="green">
                            <CheckCircle2 size={14} /> Resolved
                          </Chip>
                        ) : (
                          <Chip tone="amber">
                            <Clock size={14} /> Pending
                          </Chip>
                        )}
                      </button>
                    </td>

                    <td className="p-3 text-right">
                      <button
                        disabled={rowBusy}
                        onClick={() => del(m._id)}
                        className="inline-flex items-center gap-2 rounded-2xl border px-3 py-2 font-semibold text-red-600 hover:bg-red-50 disabled:opacity-60"
                      >
                        <Trash2 size={16} />
                        Delete
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* View modal */}
      <Modal
        open={viewOpen}
        title="Message"
        onClose={() => {
          setViewOpen(false);
          setViewItem(null);
        }}
        footer={
          <button
            onClick={() => {
              setViewOpen(false);
              setViewItem(null);
            }}
            className="px-4 py-2 rounded-2xl border font-semibold"
          >
            Close
          </button>
        }
      >
        <div className="space-y-2">
          <div className="text-sm text-gray-600">
            <span className="font-semibold text-gray-900">From:</span>{" "}
            {viewItem?.firstName} {viewItem?.lastName} • {viewItem?.email}
          </div>
          <div className="rounded-2xl border bg-gray-50 p-4 text-gray-800 whitespace-pre-wrap">
            {viewItem?.description || "-"}
          </div>
        </div>
      </Modal>
    </div>
  );
}