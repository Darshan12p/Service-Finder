import React from "react";
import { Mail, MapPin, Phone, Pencil, Shield } from "lucide-react";

export default function Profile() {
  const admin =
    JSON.parse(localStorage.getItem("admin") || "null") ||
    JSON.parse(localStorage.getItem("user") || "null");

  const name = admin?.name || admin?.fullName || "Admin";
  const role = admin?.role || "Admin";
  const email = admin?.email || "admin@example.com";
  const phone = admin?.phone || "+91 XXXXX XXXXX";
  const location = admin?.location || "India";

  return (
    <div className="p-6">
      <h2 className="text-lg font-bold text-gray-800">My Profile</h2>

      <div className="mt-4 rounded-2xl border bg-white overflow-hidden">
        {/* top gradient header */}
        <div className="h-28 bg-linear-to-r from-indigo-400 to-purple-300" />

        {/* avatar + name */}
        <div className="-mt-10 flex flex-col items-center px-6 pb-8">
          <div className="w-20 h-20 rounded-full bg-white p-1 shadow">
            <img
              src={admin?.avatar || "https://i.pravatar.cc/150?img=12"}
              alt="avatar"
              className="w-full h-full rounded-full object-cover"
            />
          </div>

          <p className="mt-3 text-lg font-extrabold text-gray-900">{name}</p>
          <p className="text-sm text-gray-500">{role}</p>

          {/* cards */}
          <div className="mt-6 w-full max-w-3xl space-y-4">
            {/* Contact Info */}
            <div className="rounded-xl border p-5">
              <div className="flex items-center justify-between">
                <p className="font-bold text-gray-800">Contact Information</p>

                <button className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-50 text-indigo-700 text-sm font-semibold">
                  <Pencil size={16} />
                  Edit
                </button>
              </div>

              <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="flex items-center gap-3">
                  <Phone size={18} className="text-indigo-600" />
                  <p className="text-sm text-gray-700">{phone}</p>
                </div>

                <div className="flex items-center gap-3">
                  <Mail size={18} className="text-indigo-600" />
                  <p className="text-sm text-gray-700">{email}</p>
                </div>

                <div className="flex items-center gap-3">
                  <MapPin size={18} className="text-indigo-600" />
                  <p className="text-sm text-gray-700">{location}</p>
                </div>
              </div>
            </div>

            {/* Security */}
            <div className="rounded-xl border p-5">
              <div className="flex items-center justify-between">
                <p className="font-bold text-gray-800">Security</p>
                <button className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-sm font-semibold">
                  Change Password
                </button>
              </div>

              <div className="mt-4 flex items-center gap-3 text-gray-600">
                <Shield size={18} className="text-indigo-600" />
                <p className="text-sm">••••••••••••••</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
