import React, { useEffect, useMemo, useState } from "react";
import {
  adminDeleteJoinInquiryApi,
  adminGetJoinInquiriesApi,
  adminUpdateJoinInquiryStatusApi,
} from "../../services/api";
import { Search, Trash2, FileText, Copy, X } from "lucide-react";
import Swal from "sweetalert2";
const FILE_BASE = "http://localhost:5000";

const cn = (...s) => s.filter(Boolean).join(" ");

function Chip({ tone = "gray", children }) {
  const map = {
    gray: "bg-gray-100 text-gray-700 border-gray-200",
    green: "bg-green-100 text-green-700 border-green-200",
    red: "bg-red-100 text-red-700 border-red-200",
    amber: "bg-amber-100 text-amber-700 border-amber-200",
    indigo: "bg-indigo-100 text-indigo-700 border-indigo-200",
  };
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs font-semibold", map[tone] || map.gray)}>
      {children}
    </span>
  );
}

function Modal({ open, title, onClose, children, footer }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-70 bg-black/40 backdrop-blur-[1px] flex items-center justify-center p-4">
      <div className="w-full max-w-3xl rounded-3xl border bg-white shadow-xl overflow-hidden">
        <div className="p-5 border-b flex items-start justify-between gap-4">
          <h3 className="text-lg font-extrabold text-gray-900">{title}</h3>
          <button onClick={onClose} className="w-10 h-10 rounded-2xl border hover:bg-gray-50 grid place-items-center">
            <X size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
        {footer ? <div className="p-5 border-t bg-gray-50/60">{footer}</div> : null}
      </div>
    </div>
  );
}

export default function JoinInquiries() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);

  // filters
  const [status, setStatus] = useState("all"); // all|pending|approved|rejected
  const [search, setSearch] = useState("");
  const [searchDebounced, setSearchDebounced] = useState("");
  const [note, setNote] = useState({ type: "info", msg: "" });
  const [busyId, setBusyId] = useState("");

  // details modal (optional: cleaner for long data)
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(null);

  const showNote = (type, msg) => {
    setNote({ type, msg });
    window.clearTimeout(window.__ji_note_to);
    window.__ji_note_to = window.setTimeout(() => setNote({ type: "info", msg: "" }), 2200);
  };

  useEffect(() => {
    const t = setTimeout(() => setSearchDebounced(search.trim()), 450);
    return () => clearTimeout(t);
  }, [search]);

  const load = async () => {
    setLoading(true);
    try {
      const res = await adminGetJoinInquiriesApi({ status, search: searchDebounced });
      setItems(res?.data?.items || []);
    } catch (e) {
      showNote("error", e?.response?.data?.message || "Failed to load inquiries");
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line
  }, [status, searchDebounced]);

  const stats = useMemo(() => {
    const total = items.length;
    const pending = items.filter((x) => (x.status || "pending") === "pending").length;
    const approved = items.filter((x) => x.status === "approved").length;
    const rejected = items.filter((x) => x.status === "rejected").length;
    return { total, pending, approved, rejected };
  }, [items]);

  const docUrl = (it) => {
    if (!it?.documentUrl) return "";
    if (it.documentUrl.startsWith("http")) return it.documentUrl;
    return `${FILE_BASE}${it.documentUrl}`;
  };

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      showNote("success", "Copied");
    } catch {
      showNote("error", "Copy failed");
    }
  };

  const changeStatus = async (id, newStatus) => {
    try {
      setBusyId(id);
      await adminUpdateJoinInquiryStatusApi(id, newStatus);
      showNote("success", "Status updated");
      load();
    } catch (e) {
      showNote("error", e?.response?.data?.message || "Failed to update status");
    } finally {
      setBusyId("");
    }
  };

  const del = async (id) => {
  const result = await Swal.fire({
    title: "Are you sure?",
    text: "This inquiry will be permanently deleted.",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#dc2626",
    cancelButtonColor: "#6b7280",
    confirmButtonText: "Yes, delete it!",
    cancelButtonText: "Cancel",
    reverseButtons: true,
  });

  if (!result.isConfirmed) return;

  try {
    setBusyId(id);

    await Swal.fire({
      title: "Deleting...",
      text: "Please wait",
      allowOutsideClick: false,
      allowEscapeKey: false,
      didOpen: () => {
        Swal.showLoading();
      },
    });

    await adminDeleteJoinInquiryApi(id);

    Swal.close();

    await Swal.fire({
      title: "Deleted!",
      text: "Inquiry has been deleted successfully.",
      icon: "success",
      confirmButtonColor: "#4f46e5",
      timer: 1500,
      showConfirmButton: false,
    });

    showNote("success", "Inquiry deleted");
    load();
  } catch (e) {
    Swal.close();
    Swal.fire({
      title: "Error",
      text: e?.response?.data?.message || "Failed to delete",
      icon: "error",
      confirmButtonColor: "#dc2626",
    });
    showNote("error", e?.response?.data?.message || "Failed to delete");
  } finally {
    setBusyId("");
  }
};

  const noteTone =
    note.type === "success"
      ? "bg-green-50 text-green-800 border-green-200"
      : note.type === "error"
      ? "bg-red-50 text-red-800 border-red-200"
      : "bg-gray-50 text-gray-800 border-gray-200";

  const statusTone = (s) => {
    if (s === "approved") return "green";
    if (s === "rejected") return "red";
    return "amber";
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="mb-5 rounded-3xl border bg-linear-to-br from-indigo-50 via-white to-white p-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-3xl font-extrabold text-gray-900">Join Us Inquiries</h1>
            <p className="text-sm text-gray-600 mt-1">
              Review applications, update status, and download documents.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
            <select
              className="border rounded-2xl px-3 py-2 bg-white"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="all">All</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>

            <div className="flex items-center gap-2 border rounded-2xl bg-white px-3 py-2 w-full sm:w-96">
              <Search size={18} className="text-gray-400" />
              <input
                className="w-full outline-none text-sm"
                placeholder="Search name / email / phone / role..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <button
              onClick={load}
              className="rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 font-semibold shadow-sm"
            >
              Refresh
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="rounded-2xl border bg-white p-4 shadow-sm">
            <p className="text-xs font-semibold text-gray-500">Total</p>
            <p className="text-2xl font-extrabold text-gray-900 mt-1">{stats.total}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4 shadow-sm">
            <p className="text-xs font-semibold text-gray-500">Pending</p>
            <p className="text-2xl font-extrabold text-gray-900 mt-1">{stats.pending}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4 shadow-sm">
            <p className="text-xs font-semibold text-gray-500">Approved</p>
            <p className="text-2xl font-extrabold text-gray-900 mt-1">{stats.approved}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4 shadow-sm">
            <p className="text-xs font-semibold text-gray-500">Rejected</p>
            <p className="text-2xl font-extrabold text-gray-900 mt-1">{stats.rejected}</p>
          </div>
        </div>

        {/* Note */}
        {note.msg ? (
          <div className={cn("mt-4 rounded-2xl border px-4 py-3 text-sm font-semibold", noteTone)}>
            {note.msg}
          </div>
        ) : null}
      </div>

      {/* Table */}
      <div className="bg-white rounded-3xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b text-sm text-gray-600">
          {loading ? "Loading..." : `Total: ${items.length}`}
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-gray-600 sticky top-0">
              <tr className="text-xs font-extrabold">
                <th className="text-left p-3">Candidate</th>
                <th className="text-left p-3">Education</th>
                <th className="text-left p-3">Professional</th>
                <th className="text-left p-3">Skills</th>
                <th className="text-left p-3">Document</th>
                <th className="text-left p-3">Status</th>
                <th className="text-right p-3">Actions</th>
              </tr>
            </thead>

            <tbody>
              {!loading && items.length === 0 ? (
                <tr>
                  <td className="p-6 text-center text-gray-500" colSpan={7}>
                    No inquiries found
                  </td>
                </tr>
              ) : null}

              {items.map((it, idx) => {
                const docLink = docUrl(it);
                const s = it.status || "pending";
                const rowBusy = busyId === it._id;

                return (
                  <tr
                    key={it._id}
                    className={cn(
                      "border-t align-top",
                      idx % 2 === 0 ? "bg-white" : "bg-gray-50/40",
                      "hover:bg-indigo-50/30"
                    )}
                  >
                    {/* Candidate */}
                    <td className="p-3">
                      <div className="font-extrabold text-gray-900">{it.fullName}</div>

                      <div className="mt-2 space-y-1 text-xs text-gray-600">
                        <div className="flex items-center justify-between gap-2">
                          <span className="truncate">{it.email}</span>
                          {it.email ? (
                            <button
                              onClick={() => copy(it.email)}
                              className="p-2 rounded-xl border hover:bg-gray-50"
                              title="Copy email"
                            >
                              <Copy size={14} />
                            </button>
                          ) : null}
                        </div>

                        <div className="flex items-center justify-between gap-2">
                          <span>{it.phone}</span>
                          {it.phone ? (
                            <button
                              onClick={() => copy(it.phone)}
                              className="p-2 rounded-xl border hover:bg-gray-50"
                              title="Copy phone"
                            >
                              <Copy size={14} />
                            </button>
                          ) : null}
                        </div>

                        <div>Gender: {it.gender || "-"}</div>
                        <div>DOB: {it.dob || "-"}</div>
                      </div>

                      <div className="text-[11px] text-gray-400 mt-2">
                        {it.createdAt ? new Date(it.createdAt).toLocaleString() : ""}
                      </div>

                      <button
                        onClick={() => {
                          setSelected(it);
                          setOpen(true);
                        }}
                        className="mt-3 text-xs font-semibold text-indigo-600 hover:underline"
                      >
                        View details
                      </button>
                    </td>

                    {/* Education */}
                    <td className="p-3">
                      <div className="text-sm text-gray-800 space-y-1">
                        <div>
                          <span className="text-gray-500">Degree:</span>{" "}
                          {it.education?.degree || "-"}
                        </div>
                        <div>
                          <span className="text-gray-500">Institute:</span>{" "}
                          {it.education?.institute || "-"}
                        </div>
                        <div>
                          <span className="text-gray-500">Year:</span>{" "}
                          {it.education?.passingYear || "-"}
                        </div>
                      </div>
                    </td>

                    {/* Professional */}
                    <td className="p-3">
                      <div className="text-sm text-gray-800 space-y-1">
                        <div>
                          <span className="text-gray-500">Exp:</span>{" "}
                          {it.professional?.experienceYears ?? "-"}
                        </div>
                        <div>
                          <span className="text-gray-500">Role:</span>{" "}
                          {it.professional?.currentRole || "-"}
                        </div>

                        {it.professional?.about ? (
                          <div className="mt-2 text-xs text-gray-700 line-clamp-3">
                            <span className="text-gray-500">About:</span>{" "}
                            {it.professional.about}
                          </div>
                        ) : null}
                      </div>
                    </td>

                    {/* Skills */}
                    <td className="p-3">
                      {Array.isArray(it.skills) && it.skills.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {it.skills.slice(0, 10).map((sk, i) => (
                            <span
                              key={i}
                              className="px-2 py-1 rounded-full text-xs bg-indigo-50 text-indigo-700 border border-indigo-100"
                            >
                              {sk}
                            </span>
                          ))}
                          {it.skills.length > 10 ? (
                            <span className="text-xs text-gray-500 ml-1">
                              +{it.skills.length - 10} more
                            </span>
                          ) : null}
                        </div>
                      ) : (
                        <span className="text-gray-400 text-xs">-</span>
                      )}
                    </td>

                    {/* Document */}
                    <td className="p-3">
                      {docLink ? (
                        <a
                          href={docLink}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-2 rounded-2xl border px-3 py-2 font-semibold text-indigo-600 hover:bg-indigo-50"
                        >
                          <FileText size={16} />
                          View
                        </a>
                      ) : (
                        <span className="text-gray-400 text-xs">No file</span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="p-3">
                      <div className="mb-2">
                        <Chip tone={statusTone(s)}>
                          {s === "approved" ? "Approved" : s === "rejected" ? "Rejected" : "Pending"}
                        </Chip>
                      </div>

                      <select
                        disabled={rowBusy}
                        className={cn(
                          "border rounded-2xl px-3 py-2 text-sm w-full bg-white disabled:opacity-60",
                          s === "approved"
                            ? "bg-green-50"
                            : s === "rejected"
                            ? "bg-red-50"
                            : "bg-amber-50"
                        )}
                        value={s}
                        onChange={(e) => changeStatus(it._id, e.target.value)}
                      >
                        <option value="pending">Pending</option>
                        <option value="approved">Approved</option>
                        <option value="rejected">Rejected</option>
                      </select>
                    </td>

                    {/* Actions */}
                    <td className="p-3 text-right">
                      <button
                        disabled={rowBusy}
                        onClick={() => del(it._id)}
                        className="inline-flex items-center gap-2 rounded-2xl border px-3 py-2 font-semibold text-red-600 hover:bg-red-50 disabled:opacity-60"
                      >
                        <Trash2 size={16} />
                        Delete
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Details Modal */}
      <Modal
        open={open}
        title="Inquiry Details"
        onClose={() => {
          setOpen(false);
          setSelected(null);
        }}
        footer={
          <button
            onClick={() => {
              setOpen(false);
              setSelected(null);
            }}
            className="px-4 py-2 rounded-2xl border font-semibold"
          >
            Close
          </button>
        }
      >
        <div className="space-y-4">
          <div className="rounded-2xl border bg-gray-50 p-4">
            <div className="font-extrabold text-gray-900">{selected?.fullName}</div>
            <div className="text-sm text-gray-600 mt-1">
              {selected?.email} • {selected?.phone}
            </div>
            <div className="text-xs text-gray-500 mt-2">
              {selected?.createdAt ? new Date(selected.createdAt).toLocaleString() : ""}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="rounded-2xl border p-4">
              <div className="text-xs font-semibold text-gray-500">Education</div>
              <div className="mt-2 text-sm text-gray-800 space-y-1">
                <div>Degree: {selected?.education?.degree || "-"}</div>
                <div>Institute: {selected?.education?.institute || "-"}</div>
                <div>Year: {selected?.education?.passingYear || "-"}</div>
              </div>
            </div>

            <div className="rounded-2xl border p-4">
              <div className="text-xs font-semibold text-gray-500">Professional</div>
              <div className="mt-2 text-sm text-gray-800 space-y-1">
                <div>Experience: {selected?.professional?.experienceYears ?? "-"}</div>
                <div>Role: {selected?.professional?.currentRole || "-"}</div>
                <div className="text-xs text-gray-600 mt-2 whitespace-pre-wrap">
                  {selected?.professional?.about || "-"}
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border p-4">
            <div className="text-xs font-semibold text-gray-500">Skills</div>
            <div className="mt-2">
              {Array.isArray(selected?.skills) && selected.skills.length ? (
                <div className="flex flex-wrap gap-1">
                  {selected.skills.map((sk, i) => (
                    <span key={i} className="px-2 py-1 rounded-full text-xs bg-indigo-50 text-indigo-700 border border-indigo-100">
                      {sk}
                    </span>
                  ))}
                </div>
              ) : (
                <div className="text-sm text-gray-500">-</div>
              )}
            </div>
          </div>

          {docUrl(selected) ? (
            <a
              href={docUrl(selected)}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-2xl border px-4 py-2 font-semibold text-indigo-600 hover:bg-indigo-50"
            >
              <FileText size={16} />
              View Document
            </a>
          ) : null}
        </div>
      </Modal>

      {note.msg ? (
        <div className={cn("fixed bottom-5 right-5 rounded-2xl border px-4 py-3 text-sm font-semibold shadow-sm", noteTone)}>
          {note.msg}
        </div>
      ) : null}
    </div>
  );
}