import React, { useEffect, useMemo, useState } from "react";
import {
  Plus,
  Search,
  Trash2,
  Power,
  ListChecks,
  X,
  Tag,
  BadgePercent,
  IndianRupee,
  SlidersHorizontal,
  CheckCheck,
} from "lucide-react";
import {
  adminGetOffersApi,
  adminCreateOfferApi,
  adminToggleOfferApi,
  adminDeleteOfferApi,
  adminAssignOfferServicesApi,
  getServicesApi,
} from "../../services/api";

const DEFAULT_FORM = {
  title: "",
  code: "",
  discountType: "percent",
  value: 10,
  isActive: true,
};

const cn = (...s) => s.filter(Boolean).join(" ");

function Chip({ children, tone = "gray" }) {
  const map = {
    gray: "bg-gray-100 text-gray-700 border-gray-200",
    green: "bg-green-100 text-green-700 border-green-200",
    red: "bg-red-100 text-red-700 border-red-200",
    indigo: "bg-indigo-100 text-indigo-700 border-indigo-200",
    amber: "bg-amber-100 text-amber-700 border-amber-200",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs font-semibold",
        map[tone] || map.gray
      )}
    >
      {children}
    </span>
  );
}

function StatCard({ icon: Icon, label, value, sub }) {
  return (
    <div className="rounded-2xl border bg-white p-4 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold text-gray-500">{label}</p>
          <p className="mt-1 text-2xl font-extrabold text-gray-900">{value}</p>
          {sub ? <p className="mt-1 text-xs text-gray-500">{sub}</p> : null}
        </div>
        <div className="grid h-10 w-10 place-items-center rounded-2xl bg-gray-50 border">
          <Icon size={18} className="text-gray-700" />
        </div>
      </div>
    </div>
  );
}

function ModalShell({ title, desc, onClose, children, footer }) {
  return (
    <div className="fixed inset-0 z-70 bg-black/40 backdrop-blur-[1px] flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-xl border overflow-hidden">
        <div className="p-5 border-b flex items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-extrabold text-gray-900">{title}</h2>
            {desc ? <p className="text-sm text-gray-500 mt-1">{desc}</p> : null}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 rounded-2xl border hover:bg-gray-50 grid place-items-center"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-5">{children}</div>

        {footer ? <div className="p-5 border-t bg-gray-50/60">{footer}</div> : null}
      </div>
    </div>
  );
}

export default function Offers() {
  const [offers, setOffers] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  // create offer modal
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(DEFAULT_FORM);

  // assign services modal
  const [assignOpen, setAssignOpen] = useState(false);
  const [assignOffer, setAssignOffer] = useState(null);
  const [selectedServiceIds, setSelectedServiceIds] = useState([]);
  const [serviceQ, setServiceQ] = useState("");

  // list controls
  const [q, setQ] = useState("");
  const [statusFilter, setStatusFilter] = useState("all"); // all | active | inactive
  const [sortBy, setSortBy] = useState("newest"); // newest | oldest | title | discount

  // feedback
  const [note, setNote] = useState({ type: "info", msg: "" });
  const showNote = (type, msg) => {
    setNote({ type, msg });
    // auto clear
    window.clearTimeout(window.__offers_note_to);
    window.__offers_note_to = window.setTimeout(() => {
      setNote({ type: "info", msg: "" });
    }, 2200);
  };

  const loadAll = async () => {
    try {
      setLoading(true);
      const [oRes, sRes] = await Promise.all([
        adminGetOffersApi(),
        getServicesApi({ page: 1, limit: 500 }),
      ]);

      setOffers(oRes.data.offers || []);

      const list = sRes?.data?.items || sRes?.data?.services || [];
      setServices(Array.isArray(list) ? list : []);
    } catch (e) {
      console.error(e);
      showNote("error", e?.response?.data?.message || "Failed to load data");
      setOffers([]);
      setServices([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const serviceNameById = (id) =>
    services.find((s) => s._id === id)?.title || "Service";

  const stats = useMemo(() => {
    const total = offers.length;
    const active = offers.filter((o) => o.isActive).length;
    const inactive = total - active;
    const avg =
      total === 0
        ? 0
        : Math.round(
            offers.reduce((sum, o) => sum + Number(o.value || 0), 0) / total
          );
    return { total, active, inactive, avg };
  }, [offers]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    let list = offers;

    if (statusFilter === "active") list = list.filter((o) => o.isActive);
    if (statusFilter === "inactive") list = list.filter((o) => !o.isActive);

    if (s) {
      list = list.filter(
        (o) =>
          o.title?.toLowerCase().includes(s) ||
          o.code?.toLowerCase().includes(s)
      );
    }

    const safeDate = (d) => (d ? new Date(d).getTime() : 0);
    const discountScore = (o) => {
      // percent offers weight higher than fixed for sorting consistency
      const v = Number(o.value || 0);
      return o.discountType === "percent" ? v * 1000 : v;
    };

    const sorted = [...list].sort((a, b) => {
      if (sortBy === "newest") return safeDate(b.createdAt) - safeDate(a.createdAt);
      if (sortBy === "oldest") return safeDate(a.createdAt) - safeDate(b.createdAt);
      if (sortBy === "title") return String(a.title || "").localeCompare(String(b.title || ""));
      if (sortBy === "discount") return discountScore(b) - discountScore(a);
      return 0;
    });

    return sorted;
  }, [offers, q, statusFilter, sortBy]);

  const createOffer = async () => {
    try {
      if (!form.title.trim()) return showNote("error", "Title required");
      if (!form.code.trim()) return showNote("error", "Code required");
      if (Number(form.value) <= 0) return showNote("error", "Value must be > 0");

      const payload = {
        ...form,
        code: form.code.trim().toUpperCase().replace(/\s+/g, ""),
      };

      await adminCreateOfferApi(payload);
      setOpen(false);
      setForm(DEFAULT_FORM);
      showNote("success", "Offer created");
      loadAll();
    } catch (e) {
      console.error(e);
      showNote("error", e?.response?.data?.message || "Failed to create offer");
    }
  };

  const toggleOffer = async (id) => {
    try {
      await adminToggleOfferApi(id);
      showNote("success", "Status updated");
      loadAll();
    } catch (e) {
      console.error(e);
      showNote("error", e?.response?.data?.message || "Failed to toggle offer");
    }
  };

  const deleteOffer = async (id) => {
    const ok = confirm("Delete this offer permanently?");
    if (!ok) return;
    try {
      await adminDeleteOfferApi(id);
      showNote("success", "Offer deleted");
      loadAll();
    } catch (e) {
      console.error(e);
      showNote("error", e?.response?.data?.message || "Failed to delete offer");
    }
  };

  const openAssign = (offer) => {
    setAssignOffer(offer);
    setSelectedServiceIds(offer?.serviceIds || []);
    setServiceQ("");
    setAssignOpen(true);
  };

  const saveAssign = async () => {
    try {
      if (!assignOffer?._id) return;

      await adminAssignOfferServicesApi(assignOffer._id, selectedServiceIds);
      showNote("success", "Services assigned");
      setAssignOpen(false);
      setAssignOffer(null);
      setSelectedServiceIds([]);
      loadAll();
    } catch (e) {
      console.error(e);
      showNote("error", e?.response?.data?.message || "Failed to assign services");
    }
  };

  const actionBtn =
    "px-3 py-2 rounded-2xl border hover:bg-gray-50 flex items-center gap-2 " +
    "cursor-pointer select-none outline-none " +
    "focus:outline-none focus:ring-0 focus-visible:ring-0 text-sm font-semibold";

  const noteTone =
    note.type === "success"
      ? "bg-green-50 text-green-800 border-green-200"
      : note.type === "error"
      ? "bg-red-50 text-red-800 border-red-200"
      : "bg-gray-50 text-gray-800 border-gray-200";

  const filteredServices = useMemo(() => {
    const s = serviceQ.trim().toLowerCase();
    if (!s) return services;
    return services.filter(
      (x) =>
        x.title?.toLowerCase().includes(s) ||
        x.categoryName?.toLowerCase().includes(s) ||
        x.category?.toLowerCase().includes(s)
    );
  }, [services, serviceQ]);

  const allVisibleSelected =
    filteredServices.length > 0 &&
    filteredServices.every((x) => selectedServiceIds.includes(x._id));

  const toggleSelectAllVisible = () => {
    const ids = filteredServices.map((x) => x._id);
    if (allVisibleSelected) {
      setSelectedServiceIds((prev) => prev.filter((id) => !ids.includes(id)));
    } else {
      setSelectedServiceIds((prev) => Array.from(new Set([...prev, ...ids])));
    }
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between mb-5">
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">
            Offers
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Create offers and assign them to services (shown on user side).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-2xl font-semibold shadow-sm"
          >
            <Plus size={18} className="pointer-events-none" />
            <span className="pointer-events-none">Add Offer</span>
          </button>
        </div>
      </div>

      {/* Note */}
      {note.msg ? (
        <div className={cn("mb-4 rounded-2xl border px-4 py-3 text-sm font-semibold", noteTone)}>
          {note.msg}
        </div>
      ) : null}

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard icon={Tag} label="Total offers" value={stats.total} />
        <StatCard icon={CheckCheck} label="Active" value={stats.active} />
        <StatCard icon={Power} label="Inactive" value={stats.inactive} />
        <StatCard
          icon={BadgePercent}
          label="Avg value"
          value={stats.avg}
          sub="(simple average)"
        />
      </div>

      {/* Controls */}
      <div className="bg-white rounded-2xl shadow-sm border p-4 mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-3 flex-1">
          <div className="flex items-center gap-2 flex-1 border rounded-2xl px-3 py-2">
            <Search size={18} className="text-gray-400" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search by title or code..."
              className="w-full outline-none text-sm"
            />
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2 text-xs text-gray-500">
              <SlidersHorizontal size={16} />
              Filters
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border rounded-2xl px-3 py-2 text-sm"
            >
              <option value="all">All</option>
              <option value="active">Active only</option>
              <option value="inactive">Inactive only</option>
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="border rounded-2xl px-3 py-2 text-sm"
              title="Sort"
            >
              <option value="newest">Newest</option>
              <option value="oldest">Oldest</option>
              <option value="title">Title (A-Z)</option>
              <option value="discount">Discount (High-Low)</option>
            </select>
          </div>
        </div>

        <div className="text-sm text-gray-500">
          Showing{" "}
          <span className="font-semibold text-gray-900">{filtered.length}</span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
        <div className="grid grid-cols-12 px-4 py-3 bg-gray-50 text-xs font-extrabold text-gray-600 sticky top-0">
          <div className="col-span-4">Offer</div>
          <div className="col-span-2">Code</div>
          <div className="col-span-2">Discount</div>
          <div className="col-span-2">Services</div>
          <div className="col-span-1">Status</div>
          <div className="col-span-1 text-right">Actions</div>
        </div>

        {loading ? (
          <div className="p-6">
            <div className="h-4 w-48 bg-gray-100 rounded mb-3" />
            <div className="h-4 w-72 bg-gray-100 rounded mb-2" />
            <div className="h-4 w-60 bg-gray-100 rounded" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-6 text-sm text-gray-500">No offers found.</div>
        ) : (
          filtered.map((o, idx) => (
            <div
              key={o._id}
              className={cn(
                "grid grid-cols-12 px-4 py-4 border-t text-sm items-center",
                idx % 2 === 0 ? "bg-white" : "bg-gray-50/40",
                "hover:bg-indigo-50/30 transition"
              )}
            >
              <div className="col-span-4">
                <div className="flex items-start gap-3">
                  <div className="mt-1 grid h-9 w-9 place-items-center rounded-2xl bg-gray-50 border">
                    {o.discountType === "fixed" ? (
                      <IndianRupee size={18} className="text-gray-700" />
                    ) : (
                      <BadgePercent size={18} className="text-gray-700" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="font-extrabold text-gray-900 truncate">
                      {o.title}
                    </div>
                    <div className="text-xs text-gray-500">
                      {o.createdAt ? new Date(o.createdAt).toLocaleString() : ""}
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-span-2">
                <span className="font-mono font-semibold text-gray-900">
                  {o.code}
                </span>
              </div>

              <div className="col-span-2">
                <Chip tone="indigo">
                  {o.discountType === "fixed" ? `₹${o.value}` : `${o.value}%`}
                </Chip>
              </div>

              <div className="col-span-2">
                <div className="font-bold text-gray-900">
                  {(o.serviceIds?.length || 0)} services
                </div>
                <div className="text-xs text-gray-500 truncate">
                  {(o.serviceIds || []).slice(0, 2).map(serviceNameById).join(", ")}
                  {(o.serviceIds || []).length > 2 ? " ..." : ""}
                </div>
              </div>

              <div className="col-span-1">
                {o.isActive ? (
                  <Chip tone="green">Active</Chip>
                ) : (
                  <Chip tone="gray">Inactive</Chip>
                )}
              </div>

              <div className="col-span-1 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => openAssign(o)}
                  className={cn(actionBtn, "px-3")}
                  title="Assign Services"
                >
                  <ListChecks size={16} className="pointer-events-none" />
                </button>

                <button
                  type="button"
                  onClick={() => toggleOffer(o._id)}
                  className={cn(actionBtn, "px-3")}
                  title="Toggle Active"
                >
                  <Power size={16} className="pointer-events-none" />
                </button>

                <button
                  type="button"
                  onClick={() => deleteOffer(o._id)}
                  className={cn(actionBtn, "px-3 hover:bg-red-50 text-red-600")}
                  title="Delete"
                >
                  <Trash2 size={16} className="pointer-events-none" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* CREATE OFFER MODAL */}
      {open && (
        <ModalShell
          title="Create Offer"
          desc="Create a new offer code and set discount type/value."
          onClose={() => setOpen(false)}
          footer={
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="px-4 py-2 rounded-2xl border font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={createOffer}
                className="px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold shadow-sm"
              >
                Create
              </button>
            </div>
          }
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-gray-600">
                Title
              </label>
              <input
                className="w-full border rounded-2xl px-3 py-2 mt-1 outline-none focus:border-indigo-400"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="e.g. Summer Sale"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-600">
                Code
              </label>
              <input
                className="w-full border rounded-2xl px-3 py-2 mt-1 font-mono outline-none focus:border-indigo-400"
                value={form.code}
                onChange={(e) =>
                  setForm({
                    ...form,
                    code: e.target.value.toUpperCase().replace(/\s+/g, ""),
                  })
                }
                placeholder="e.g. SAVE10"
              />
              <p className="text-[11px] text-gray-500 mt-1">
                Tip: code auto upper-case & removes spaces.
              </p>
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-600">
                Discount Type
              </label>
              <select
                className="w-full border rounded-2xl px-3 py-2 mt-1 outline-none focus:border-indigo-400"
                value={form.discountType}
                onChange={(e) =>
                  setForm({ ...form, discountType: e.target.value })
                }
              >
                <option value="percent">Percent (%)</option>
                <option value="fixed">Fixed (₹)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-600">
                Value
              </label>
              <input
                type="number"
                className="w-full border rounded-2xl px-3 py-2 mt-1 outline-none focus:border-indigo-400"
                value={form.value}
                onChange={(e) =>
                  setForm({ ...form, value: Number(e.target.value) })
                }
                min={1}
              />
            </div>

            <div className="flex items-center gap-2 sm:col-span-2">
              <input
                id="offerActive"
                type="checkbox"
                checked={form.isActive}
                onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
                className="h-4 w-4"
              />
              <label htmlFor="offerActive" className="text-sm text-gray-700">
                Mark as Active
              </label>
            </div>
          </div>
        </ModalShell>
      )}

      {/* ASSIGN SERVICES MODAL */}
      {assignOpen && (
        <ModalShell
          title={`Assign Services → ${assignOffer?.title || ""}`}
          desc="Select services that should show this offer on user side."
          onClose={() => setAssignOpen(false)}
          footer={
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="text-sm text-gray-600">
                Selected:{" "}
                <span className="font-extrabold text-gray-900">
                  {selectedServiceIds.length}
                </span>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setAssignOpen(false)}
                  className="px-4 py-2 rounded-2xl border font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={saveAssign}
                  className="px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold shadow-sm"
                >
                  Save
                </button>
              </div>
            </div>
          }
        >
          {/* top tools */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-4">
            <div className="flex items-center gap-2 border rounded-2xl px-3 py-2 flex-1">
              <Search size={18} className="text-gray-400" />
              <input
                value={serviceQ}
                onChange={(e) => setServiceQ(e.target.value)}
                placeholder="Search services..."
                className="w-full outline-none text-sm"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleSelectAllVisible}
                className={cn(actionBtn, "whitespace-nowrap")}
                title="Select all visible"
              >
                <CheckCheck size={16} />
                {allVisibleSelected ? "Unselect All" : "Select All"}
              </button>

              <button
                type="button"
                onClick={() => setSelectedServiceIds([])}
                className={cn(actionBtn, "whitespace-nowrap")}
                title="Clear selection"
              >
                Clear
              </button>
            </div>
          </div>

          {/* list */}
          <div className="max-h-[55vh] overflow-auto pr-1">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filteredServices.map((s) => {
                const checked = selectedServiceIds.includes(s._id);
                return (
                  <button
                    type="button"
                    key={s._id}
                    onClick={() => {
                      setSelectedServiceIds((prev) =>
                        checked
                          ? prev.filter((x) => x !== s._id)
                          : [...prev, s._id]
                      );
                    }}
                    className={cn(
                      "text-left border rounded-3xl p-4 transition cursor-pointer select-none outline-none",
                      "focus:outline-none focus:ring-0 focus-visible:ring-0",
                      checked
                        ? "border-indigo-600 bg-indigo-50"
                        : "hover:bg-gray-50"
                    )}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="pointer-events-none min-w-0">
                        <div className="font-extrabold text-gray-900 truncate">
                          {s.title}
                        </div>
                        <div className="text-xs text-gray-500 mt-1 truncate">
                          {s.categoryName || s.category || ""}
                        </div>
                      </div>
                      <input type="checkbox" readOnly checked={checked} />
                    </div>
                  </button>
                );
              })}
            </div>

            {filteredServices.length === 0 ? (
              <div className="text-sm text-gray-500 mt-4">
                No services match your search.
              </div>
            ) : null}
          </div>
        </ModalShell>
      )}
    </div>
  );
}