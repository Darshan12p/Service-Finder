import React, { useEffect, useMemo, useState } from "react";
import {
  assignPartnerManuallyApi,
  deleteBookingApi,
  getAssignablePartnersApi,
  getBookingsApi,
  updateBookingStatusApi,
} from "../../services/api";
import {
  Search as SearchIcon,
  Trash2,
  RefreshCw,
  Calendar,
  IndianRupee,
  User,
  UserCheck,
  Clock3,
  Users,
} from "lucide-react";
import Swal from "sweetalert2";

const STATUS = ["All", "Pending", "Confirmed", "Completed", "Cancelled"];

const badgeByStatus = (s) => {
  const st = String(s || "").toLowerCase();
  if (st === "completed") return "bg-emerald-50 text-emerald-700 border-emerald-200";
  if (st === "confirmed") return "bg-indigo-50 text-indigo-700 border-indigo-200";
  if (st === "pending") return "bg-amber-50 text-amber-700 border-amber-200";
  if (st === "cancelled") return "bg-rose-50 text-rose-700 border-rose-200";
  return "bg-slate-50 text-slate-700 border-slate-200";
};

const badgeByPayment = (s) => {
  const st = String(s || "").toLowerCase();
  if (st.includes("paid")) return "bg-emerald-50 text-emerald-700 border-emerald-200";
  if (st.includes("pending")) return "bg-amber-50 text-amber-700 border-amber-200";
  if (st.includes("failed")) return "bg-rose-50 text-rose-700 border-rose-200";
  return "bg-slate-50 text-slate-700 border-slate-200";
};

const badgeByAssignment = (s) => {
  const st = String(s || "").toLowerCase();
  if (st === "accepted") return "bg-emerald-50 text-emerald-700 border-emerald-200";
  if (st === "assigned") return "bg-indigo-50 text-indigo-700 border-indigo-200";
  if (st === "reassigned") return "bg-violet-50 text-violet-700 border-violet-200";
  if (st === "rejected") return "bg-rose-50 text-rose-700 border-rose-200";
  if (st === "unassigned") return "bg-amber-50 text-amber-700 border-amber-200";
  return "bg-slate-50 text-slate-700 border-slate-200";
};

const fmtDateTime = (value) => {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleString();
};

const fmtDate = (value) => {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleDateString();
};

export default function BookingManagement() {
  const [items, setItems] = useState([]);
  const [status, setStatus] = useState("All");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [updatingId, setUpdatingId] = useState(null);

  const [assignOpen, setAssignOpen] = useState(false);
  const [assignBooking, setAssignBooking] = useState(null);
  const [partnerOptions, setPartnerOptions] = useState([]);
  const [partnersLoading, setPartnersLoading] = useState(false);
  const [assigningPartnerId, setAssigningPartnerId] = useState("");

  const load = async () => {
    try {
      setLoading(true);
      setMsg("");
      const res = await getBookingsApi({ status, search, page: 1, limit: 100 });
      setItems(res?.data?.items || []);
    } catch (e) {
      setMsg(e?.response?.data?.message || "Failed to load bookings");
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  const onChangeStatus = async (id, bookingStatus) => {
    try {
      setUpdatingId(id);

      setItems((prev) =>
        prev.map((b) => (b._id === id ? { ...b, bookingStatus } : b))
      );

      const res = await updateBookingStatusApi(id, bookingStatus);
      const updated = res?.data?.booking;

      if (updated?._id) {
        setItems((prev) => prev.map((b) => (b._id === id ? updated : b)));
      }

      Swal.fire({
        icon: "success",
        title: "Status updated",
        text: `Booking marked as ${bookingStatus}`,
        timer: 1400,
        showConfirmButton: false,
      });
    } catch (e) {
      Swal.fire({
        icon: "error",
        title: "Update failed",
        text: e?.response?.data?.message || "Status update failed",
      });
      load();
    } finally {
      setUpdatingId(null);
    }
  };

  const onDelete = async (id) => {
    const booking = items.find((b) => b._id === id);

    const result = await Swal.fire({
      title: "Delete booking?",
      text: `This will permanently delete booking for ${booking?.customerName || "this customer"}.`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#dc2626",
      cancelButtonColor: "#64748b",
      confirmButtonText: "Yes, delete it",
      cancelButtonText: "Cancel",
      reverseButtons: true,
    });

    if (!result.isConfirmed) return;

    try {
      await deleteBookingApi(id);

      setItems((prev) => prev.filter((b) => b._id !== id));

      await Swal.fire({
        icon: "success",
        title: "Deleted!",
        text: "Booking has been deleted successfully.",
        confirmButtonColor: "#4f46e5",
      });
    } catch (e) {
      Swal.fire({
        icon: "error",
        title: "Delete failed",
        text: e?.response?.data?.message || "Delete failed",
        confirmButtonColor: "#4f46e5",
      });
    }
  };

  const openAssignModal = async (booking) => {
    try {
      setAssignOpen(true);
      setAssignBooking(booking);
      setPartnerOptions([]);
      setAssigningPartnerId("");
      setPartnersLoading(true);

      const res = await getAssignablePartnersApi(booking._id);
      setPartnerOptions(res?.data?.items || []);
    } catch (e) {
      Swal.fire({
        icon: "error",
        title: "Failed",
        text: e?.response?.data?.message || "Could not load partners",
      });
      setAssignOpen(false);
      setAssignBooking(null);
    } finally {
      setPartnersLoading(false);
    }
  };

  const closeAssignModal = () => {
    setAssignOpen(false);
    setAssignBooking(null);
    setPartnerOptions([]);
    setAssigningPartnerId("");
    setPartnersLoading(false);
  };

  const onAssignPartner = async () => {
    if (!assignBooking?._id || !assigningPartnerId) {
      Swal.fire({
        icon: "warning",
        title: "Select partner",
        text: "Please select a partner first.",
      });
      return;
    }

    try {
      setPartnersLoading(true);

      const res = await assignPartnerManuallyApi(
        assignBooking._id,
        assigningPartnerId
      );

      const updated = res?.data?.booking;

      if (updated?._id) {
        setItems((prev) => prev.map((b) => (b._id === updated._id ? updated : b)));
      }

      closeAssignModal();

      Swal.fire({
        icon: "success",
        title: "Partner assigned",
        text: "Partner has been assigned successfully.",
        timer: 1500,
        showConfirmButton: false,
      });
    } catch (e) {
      Swal.fire({
        icon: "error",
        title: "Assignment failed",
        text: e?.response?.data?.message || "Could not assign partner",
      });
    } finally {
      setPartnersLoading(false);
    }
  };

  const stats = useMemo(() => {
    const total = items.length;
    const pending = items.filter((x) => x.bookingStatus === "Pending").length;
    const confirmed = items.filter((x) => x.bookingStatus === "Confirmed").length;
    const completed = items.filter((x) => x.bookingStatus === "Completed").length;
    const cancelled = items.filter((x) => x.bookingStatus === "Cancelled").length;
    const assigned = items.filter(
      (x) => String(x.assignmentStatus || "") !== "Unassigned" && x.assignedPartnerId
    ).length;
    const unassigned = items.filter(
      (x) => !x.assignedPartnerId || String(x.assignmentStatus || "") === "Unassigned"
    ).length;
    const revenue = items.reduce((sum, b) => sum + Number(b.amount || 0), 0);
    return {
      total,
      pending,
      confirmed,
      completed,
      cancelled,
      assigned,
      unassigned,
      revenue,
    };
  }, [items]);

  const StatusChip = ({ label }) => {
    const active = status === label;
    return (
      <button
        onClick={() => setStatus(label)}
        className={[
          "px-4 py-2 rounded-full text-sm font-extrabold border transition",
          active
            ? "bg-indigo-600 text-white border-indigo-600"
            : "bg-white text-slate-800 border-slate-200 hover:bg-slate-50",
        ].join(" ")}
      >
        {label}
      </button>
    );
  };

  const Badge = ({ children, className = "" }) => (
    <span
      className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-extrabold border ${className}`}
    >
      {children}
    </span>
  );

  return (
    <div className="min-h-screen bg-slate-50 p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Booking Management
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              View bookings, assigned partners, payment details and booking lifecycle.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={load}
              className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-3 font-extrabold hover:bg-slate-50"
            >
              <RefreshCw size={18} />
              Refresh
            </button>
            {loading ? (
              <span className="text-sm font-semibold text-slate-500">Loading…</span>
            ) : null}
          </div>
        </div>

        {msg ? (
          <div className="mt-4 rounded-2xl border bg-white p-3 text-sm text-slate-700">
            {msg}
          </div>
        ) : null}

        <div className="mt-5 grid grid-cols-2 lg:grid-cols-8 gap-4">
          <div className="rounded-2xl border bg-white p-4">
            <p className="text-xs font-bold text-slate-500">TOTAL</p>
            <p className="mt-1 text-2xl font-extrabold text-slate-900">{stats.total}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4">
            <p className="text-xs font-bold text-slate-500">PENDING</p>
            <p className="mt-1 text-2xl font-extrabold text-amber-700">{stats.pending}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4">
            <p className="text-xs font-bold text-slate-500">CONFIRMED</p>
            <p className="mt-1 text-2xl font-extrabold text-indigo-700">{stats.confirmed}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4">
            <p className="text-xs font-bold text-slate-500">COMPLETED</p>
            <p className="mt-1 text-2xl font-extrabold text-emerald-700">{stats.completed}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4">
            <p className="text-xs font-bold text-slate-500">CANCELLED</p>
            <p className="mt-1 text-2xl font-extrabold text-rose-700">{stats.cancelled}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4">
            <p className="text-xs font-bold text-slate-500">ASSIGNED</p>
            <p className="mt-1 text-2xl font-extrabold text-blue-700">{stats.assigned}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4">
            <p className="text-xs font-bold text-slate-500">UNASSIGNED</p>
            <p className="mt-1 text-2xl font-extrabold text-amber-700">{stats.unassigned}</p>
          </div>
          <div className="rounded-2xl border bg-white p-4">
            <p className="text-xs font-bold text-slate-500">REVENUE</p>
            <p className="mt-1 text-2xl font-extrabold text-slate-900">₹{stats.revenue}</p>
          </div>
        </div>

        <div className="mt-5 rounded-3xl border bg-white p-4 sm:p-5">
          <div className="flex flex-col gap-4">
            <div className="flex gap-2 flex-wrap">
              {STATUS.map((s) => (
                <StatusChip key={s} label={s} />
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
              <div className="lg:col-span-2">
                <div className="flex items-center gap-2 rounded-2xl border bg-slate-50 px-3 py-2">
                  <SearchIcon size={18} className="text-slate-500" />
                  <input
                    className="w-full bg-transparent outline-none text-sm"
                    placeholder="Search name / email / service / address / partner..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                  <button
                    className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-extrabold text-white hover:bg-black"
                    onClick={load}
                  >
                    Search
                  </button>
                </div>
              </div>

              <div className="rounded-2xl border bg-white px-4 py-3 text-sm font-semibold text-slate-600 flex items-center justify-between">
                <span>Showing</span>
                <span className="font-extrabold text-slate-900">{items.length}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-5 hidden xl:block rounded-3xl border bg-white overflow-hidden">
          <div className="p-4 border-b flex items-center justify-between">
            <p className="font-extrabold text-slate-900">Bookings</p>
            <p className="text-sm text-slate-600">
              Tip: You can now assign or reassign partners from here.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="text-left p-3">Customer</th>
                  <th className="text-left p-3">Service</th>
                  <th className="text-left p-3">Package</th>
                  <th className="text-left p-3">Slot</th>
                  <th className="text-left p-3">Partner</th>
                  <th className="text-left p-3">Amount</th>
                  <th className="text-left p-3">Payment</th>
                  <th className="text-left p-3">Status</th>
                  <th className="text-right p-3">Action</th>
                </tr>
              </thead>

              <tbody>
                {items.map((b) => {
                  const isUpdating = updatingId === b._id;

                  return (
                    <tr key={b._id} className="border-t align-top hover:bg-slate-50/60">
                      <td className="p-3">
                        <div className="font-extrabold text-slate-900">{b.customerName}</div>
                        <div className="text-slate-500">{b.customerEmail}</div>
                        {b.phone ? <div className="text-slate-500">{b.phone}</div> : null}
                        {b?.address?.line1 ? (
                          <div className="text-slate-500 mt-1 max-w-[260px]">
                            {b.address.line1}
                            {b.address.city ? `, ${b.address.city}` : ""}
                            {b.address.pincode ? ` - ${b.address.pincode}` : ""}
                          </div>
                        ) : null}
                      </td>

                      <td className="p-3">
                        <div className="font-extrabold text-slate-900">{b.serviceTitle}</div>
                        <div className="text-slate-500">{b.serviceCategory}</div>
                      </td>

                      <td className="p-3">
                        <div className="font-extrabold text-slate-900">{b.packageName}</div>
                        <div className="text-slate-500">{b.durationMins} mins</div>
                        <div className="text-slate-900 font-extrabold">₹{b.packagePrice}</div>
                      </td>

                      <td className="p-3">
                        <div className="font-extrabold text-slate-900">
                          {fmtDate(b?.slot?.date)}
                        </div>
                        <div className="text-slate-500">{b?.slot?.time || "-"}</div>
                      </td>

                      <td className="p-3 min-w-[260px]">
                        {b.assignedPartnerId ? (
                          <div>
                            <div className="font-extrabold text-slate-900">
                              {b.assignedPartnerName || "Assigned Partner"}
                            </div>
                            {b.assignedPartnerEmail ? (
                              <div className="text-slate-500">{b.assignedPartnerEmail}</div>
                            ) : null}
                            {b.assignedPartnerPhone ? (
                              <div className="text-slate-500">{b.assignedPartnerPhone}</div>
                            ) : null}

                            <div className="mt-2 flex flex-wrap gap-2">
                              <Badge className={badgeByAssignment(b.assignmentStatus)}>
                                {b.assignmentStatus || "Assigned"}
                              </Badge>

                              {b.assignmentMethod ? (
                                <Badge className="bg-slate-50 text-slate-700 border-slate-200">
                                  {b.assignmentMethod}
                                </Badge>
                              ) : null}
                            </div>

                            {b.assignedAt ? (
                              <div className="mt-2 text-xs text-slate-500">
                                Assigned: {fmtDateTime(b.assignedAt)}
                              </div>
                            ) : null}

                            {b.partnerResponseStatus ? (
                              <div className="text-xs text-slate-500 mt-1">
                                Partner response: {b.partnerResponseStatus}
                              </div>
                            ) : null}

                            <button
                              onClick={() => openAssignModal(b)}
                              className="mt-3 inline-flex items-center gap-2 rounded-xl border border-indigo-200 bg-indigo-50 px-3 py-2 text-sm font-extrabold text-indigo-700 hover:bg-indigo-100"
                            >
                              <Users size={16} />
                              Reassign
                            </button>
                          </div>
                        ) : (
                          <div>
                            <Badge className={badgeByAssignment("Unassigned")}>
                              Unassigned
                            </Badge>
                            <div className="text-xs text-slate-500 mt-2">
                              No partner assigned yet
                            </div>

                            <button
                              onClick={() => openAssignModal(b)}
                              className="mt-3 inline-flex items-center gap-2 rounded-xl border border-blue-200 bg-blue-50 px-3 py-2 text-sm font-extrabold text-blue-700 hover:bg-blue-100"
                            >
                              <Users size={16} />
                              Assign Partner
                            </button>
                          </div>
                        )}
                      </td>

                      <td className="p-3">
                        <Badge className="bg-white text-slate-900 border-slate-200">
                          <IndianRupee size={14} />
                          ₹{Number(b.amount || 0)}
                        </Badge>
                      </td>

                      <td className="p-3">
                        <div className="font-extrabold text-slate-900">{b.paymentMethod}</div>
                        <div className="mt-1">
                          <Badge className={badgeByPayment(b.paymentStatus)}>
                            {b.paymentStatus || "—"}
                          </Badge>
                        </div>
                      </td>

                      <td className="p-3">
                        <select
                          className={`border rounded-xl px-3 py-2 font-extrabold ${
                            isUpdating ? "opacity-60" : ""
                          }`}
                          value={b.bookingStatus}
                          disabled={isUpdating}
                          onChange={(e) => onChangeStatus(b._id, e.target.value)}
                        >
                          <option>Pending</option>
                          <option>Confirmed</option>
                          <option>Completed</option>
                          <option>Cancelled</option>
                        </select>

                        <div className="mt-2">
                          <Badge className={badgeByStatus(b.bookingStatus)}>
                            {b.bookingStatus}
                          </Badge>
                        </div>
                      </td>

                      <td className="p-3 text-right">
                        <button
                          className="inline-flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-sm font-extrabold text-red-700 hover:bg-red-100"
                          onClick={() => onDelete(b._id)}
                        >
                          <Trash2 size={16} />
                          Delete
                        </button>
                      </td>
                    </tr>
                  );
                })}

                {!loading && items.length === 0 ? (
                  <tr>
                    <td className="p-8 text-center text-slate-500" colSpan={9}>
                      No bookings found
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4 xl:hidden">
          {loading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="rounded-3xl border bg-white p-4">
                <div className="h-12 bg-slate-100 rounded-2xl animate-pulse" />
                <div className="mt-3 h-4 w-2/3 bg-slate-100 rounded animate-pulse" />
                <div className="mt-5 h-10 bg-slate-100 rounded-2xl animate-pulse" />
              </div>
            ))
          ) : items.length === 0 ? (
            <div className="rounded-3xl border bg-white p-8 text-center text-slate-600 md:col-span-2">
              No bookings found
            </div>
          ) : (
            items.map((b) => {
              const isUpdating = updatingId === b._id;

              return (
                <div key={b._id} className="rounded-3xl border bg-white p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
                        <User size={18} className="text-slate-500" />
                        {b.customerName}
                      </p>
                      <p className="text-sm text-slate-600">{b.customerEmail}</p>
                      {b.phone ? <p className="text-sm text-slate-600">{b.phone}</p> : null}
                    </div>

                    <Badge className={badgeByStatus(b.bookingStatus)}>
                      {b.bookingStatus}
                    </Badge>
                  </div>

                  <div className="mt-3 rounded-2xl border bg-slate-50 p-3">
                    <p className="font-extrabold text-slate-900">{b.serviceTitle}</p>
                    <p className="text-sm text-slate-600">
                      {b.packageName} • ₹{Number(b.amount || 0)}
                    </p>

                    <div className="mt-2 flex items-center gap-2 text-sm text-slate-700">
                      <Calendar size={16} className="text-slate-500" />
                      <span className="font-semibold">{fmtDate(b?.slot?.date)}</span>
                      <span className="text-slate-400">•</span>
                      <span>{b?.slot?.time || "-"}</span>
                    </div>

                    {b?.address?.line1 ? (
                      <p className="mt-2 text-sm text-slate-600">
                        {b.address.line1}
                        {b.address.city ? `, ${b.address.city}` : ""}
                      </p>
                    ) : null}
                  </div>

                  <div className="mt-3 rounded-2xl border bg-white p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <UserCheck size={16} className="text-slate-500" />
                      <p className="text-sm font-extrabold text-slate-900">
                        Partner Assignment
                      </p>
                    </div>

                    {b.assignedPartnerId ? (
                      <>
                        <p className="text-sm font-semibold text-slate-800">
                          {b.assignedPartnerName || "Assigned Partner"}
                        </p>
                        {b.assignedPartnerEmail ? (
                          <p className="text-sm text-slate-600">{b.assignedPartnerEmail}</p>
                        ) : null}
                        {b.assignedPartnerPhone ? (
                          <p className="text-sm text-slate-600">{b.assignedPartnerPhone}</p>
                        ) : null}

                        <div className="mt-2 flex flex-wrap gap-2">
                          <Badge className={badgeByAssignment(b.assignmentStatus)}>
                            {b.assignmentStatus || "Assigned"}
                          </Badge>

                          {b.assignmentMethod ? (
                            <Badge className="bg-slate-50 text-slate-700 border-slate-200">
                              {b.assignmentMethod}
                            </Badge>
                          ) : null}
                        </div>

                        {b.assignedAt ? (
                          <div className="mt-2 flex items-center gap-2 text-xs text-slate-500">
                            <Clock3 size={14} />
                            <span>{fmtDateTime(b.assignedAt)}</span>
                          </div>
                        ) : null}

                        <button
                          onClick={() => openAssignModal(b)}
                          className="mt-3 w-full inline-flex items-center justify-center gap-2 rounded-2xl border border-indigo-200 bg-indigo-50 px-4 py-3 font-extrabold text-indigo-700 hover:bg-indigo-100"
                        >
                          <Users size={18} />
                          Reassign Partner
                        </button>
                      </>
                    ) : (
                      <>
                        <Badge className={badgeByAssignment("Unassigned")}>
                          Unassigned
                        </Badge>
                        <p className="mt-2 text-sm text-slate-500">
                          No partner assigned yet
                        </p>

                        <button
                          onClick={() => openAssignModal(b)}
                          className="mt-3 w-full inline-flex items-center justify-center gap-2 rounded-2xl border border-blue-200 bg-blue-50 px-4 py-3 font-extrabold text-blue-700 hover:bg-blue-100"
                        >
                          <Users size={18} />
                          Assign Partner
                        </button>
                      </>
                    )}
                  </div>

                  <div className="mt-3 flex items-center justify-between">
                    <div>
                      <p className="text-xs text-slate-500 font-bold">PAYMENT</p>
                      <Badge className={badgeByPayment(b.paymentStatus)}>
                        {b.paymentStatus || "—"}
                      </Badge>
                    </div>

                    <select
                      className={`border rounded-2xl px-3 py-2 font-extrabold ${
                        isUpdating ? "opacity-60" : ""
                      }`}
                      value={b.bookingStatus}
                      disabled={isUpdating}
                      onChange={(e) => onChangeStatus(b._id, e.target.value)}
                    >
                      <option>Pending</option>
                      <option>Confirmed</option>
                      <option>Completed</option>
                      <option>Cancelled</option>
                    </select>
                  </div>

                  <button
                    onClick={() => onDelete(b._id)}
                    className="mt-3 w-full inline-flex items-center justify-center gap-2 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 font-extrabold text-red-700 hover:bg-red-100"
                  >
                    <Trash2 size={18} />
                    Delete Booking
                  </button>
                </div>
              );
            })
          )}
        </div>
      </div>

      {assignOpen && assignBooking ? (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <div className="w-full max-w-3xl rounded-3xl bg-white shadow-2xl overflow-hidden">
            <div className="px-6 py-4 border-b flex items-center justify-between">
              <div>
                <h2 className="text-xl font-extrabold text-slate-900">
                  {assignBooking.assignedPartnerId ? "Reassign Partner" : "Assign Partner"}
                </h2>
                <p className="text-sm text-slate-500 mt-1">
                  {assignBooking.customerName} • {assignBooking.serviceTitle}
                </p>
              </div>

              <button
                onClick={closeAssignModal}
                className="text-slate-500 hover:text-slate-900 text-lg"
              >
                ✕
              </button>
            </div>

            <div className="p-6 max-h-[70vh] overflow-y-auto">
              <div className="rounded-2xl border bg-slate-50 p-4 mb-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="font-bold text-slate-700">Customer:</span>{" "}
                    <span className="text-slate-600">{assignBooking.customerName}</span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-700">Service:</span>{" "}
                    <span className="text-slate-600">{assignBooking.serviceTitle}</span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-700">Category:</span>{" "}
                    <span className="text-slate-600">{assignBooking.serviceCategory}</span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-700">Slot:</span>{" "}
                    <span className="text-slate-600">
                      {fmtDate(assignBooking?.slot?.date)} • {assignBooking?.slot?.time || "-"}
                    </span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-700">City:</span>{" "}
                    <span className="text-slate-600">{assignBooking?.address?.city || "-"}</span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-700">Pincode:</span>{" "}
                    <span className="text-slate-600">
                      {assignBooking?.address?.pincode || "-"}
                    </span>
                  </div>
                </div>
              </div>

              {partnersLoading ? (
                <div className="py-10 text-center text-slate-500 font-semibold">
                  Loading partners...
                </div>
              ) : partnerOptions.length === 0 ? (
                <div className="py-10 text-center text-slate-500">
                  No matching partners found for this booking.
                </div>
              ) : (
                <div className="space-y-3">
                  {partnerOptions.map((p) => {
                    const active = assigningPartnerId === p._id;
                    return (
                      <button
                        key={p._id}
                        onClick={() => setAssigningPartnerId(p._id)}
                        className={`w-full text-left rounded-2xl border p-4 transition ${
                          active
                            ? "border-indigo-500 bg-indigo-50"
                            : "border-slate-200 bg-white hover:bg-slate-50"
                        }`}
                      >
                        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
                          <div>
                            <div className="font-extrabold text-slate-900">
                              {p.name || "Partner"}
                            </div>
                            <div className="text-sm text-slate-600">{p.email}</div>
                            {p.phone ? (
                              <div className="text-sm text-slate-600">{p.phone}</div>
                            ) : null}
                            {p.city ? (
                              <div className="text-sm text-slate-600">{p.city}</div>
                            ) : null}
                          </div>

                          <div className="flex flex-wrap gap-2">
                            <span className="px-3 py-1 rounded-full text-xs font-bold border bg-slate-50 text-slate-700 border-slate-200">
                              Priority: {p.priority || 0}
                            </span>
                            <span className="px-3 py-1 rounded-full text-xs font-bold border bg-slate-50 text-slate-700 border-slate-200">
                              Max/Day: {p.maxBookingsPerDay || 5}
                            </span>
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-bold border ${
                                p.isAvailable
                                  ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                                  : "bg-rose-50 text-rose-700 border-rose-200"
                              }`}
                            >
                              {p.isAvailable ? "Available" : "Unavailable"}
                            </span>
                          </div>
                        </div>

                        <div className="mt-3 text-xs text-slate-600">
                          <div>
                            <span className="font-bold">Categories:</span>{" "}
                            {(p.serviceCategories || []).length
                              ? p.serviceCategories.join(", ")
                              : "-"}
                          </div>
                          <div className="mt-1">
                            <span className="font-bold">Cities:</span>{" "}
                            {(p.cities || []).length ? p.cities.join(", ") : "-"}
                          </div>
                          <div className="mt-1">
                            <span className="font-bold">Pincodes:</span>{" "}
                            {(p.pincodes || []).length ? p.pincodes.join(", ") : "-"}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="px-6 py-4 border-t flex items-center justify-end gap-3 bg-white">
              <button
                onClick={closeAssignModal}
                className="px-5 py-2.5 rounded-xl border"
                disabled={partnersLoading}
              >
                Cancel
              </button>

              <button
                onClick={onAssignPartner}
                disabled={partnersLoading || !assigningPartnerId}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white disabled:opacity-60"
              >
                {partnersLoading ? "Saving..." : "Assign Partner"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}