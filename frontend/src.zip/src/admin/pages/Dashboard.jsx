import React, { useEffect, useMemo, useState } from "react";
import {
  Users,
  Wrench,
  IndianRupee,
  Briefcase,
  TrendingUp,
  TrendingDown,
  RefreshCcw,
} from "lucide-react";
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line,
} from "recharts";
import { getDashboardSummaryApi } from "../../services/api";

/** ---------- helpers ---------- */
function formatK(n) {
  const num = Number(n || 0);
  if (num >= 10000000) return (num / 10000000).toFixed(1) + "Cr";
  if (num >= 100000) return (num / 100000).toFixed(1) + "L";
  if (num >= 1000) return (num / 1000).toFixed(1) + "k";
  return String(num);
}

function safeArray(x) {
  return Array.isArray(x) ? x : [];
}

const COLORS = ["#4f46e5", "#22c55e", "#f97316", "#ec4899", "#8b5cf6", "#06b6d4"];

/** ---------- small UI components ---------- */
function Card({ title, right, children, className = "" }) {
  return (
    <div className={`rounded-2xl border bg-white shadow-sm ${className}`}>
      {(title || right) ? (
        <div className="flex items-start justify-between gap-3 px-5 pt-5">
          <div>{title ? <h3 className="text-sm font-semibold text-gray-900">{title}</h3> : null}</div>
          {right ? <div>{right}</div> : null}
        </div>
      ) : null}
      <div className="px-5 pb-5 pt-4">{children}</div>
    </div>
  );
}

function PillTabs({ value, onChange, items }) {
  return (
    <div className="inline-flex rounded-full border bg-gray-50 p-1">
      {items.map((it) => {
        const active = value === it.value;
        return (
          <button
            key={it.value}
            onClick={() => onChange(it.value)}
            className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${
              active ? "bg-white shadow-sm text-indigo-700" : "text-gray-600 hover:text-gray-900"
            }`}
          >
            {it.label}
          </button>
        );
      })}
    </div>
  );
}

function StatCard({ title, value, sub, icon, trend }) {
  const isUp = trend?.direction === "up";
  const isDown = trend?.direction === "down";

  return (
    <div className="rounded-2xl border bg-white shadow-sm p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-gray-500">{title}</p>
          <p className="mt-2 text-2xl font-extrabold text-gray-900">{value}</p>

          <div className="mt-2 flex items-center gap-2">
            {trend ? (
              <span
                className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-semibold ${
                  isUp
                    ? "bg-emerald-50 text-emerald-700"
                    : isDown
                    ? "bg-red-50 text-red-700"
                    : "bg-gray-100 text-gray-700"
                }`}
              >
                {isUp ? <TrendingUp size={14} /> : isDown ? <TrendingDown size={14} /> : null}
                {trend.value}
              </span>
            ) : null}

            <span className="text-xs text-gray-500">{sub}</span>
          </div>
        </div>

        <div className="rounded-2xl bg-indigo-50 p-3 text-indigo-700">{icon}</div>
      </div>
    </div>
  );
}

function CustomPieTooltip({ active, payload }) {
  if (!active || !payload?.length) return null;
  const p = payload[0]?.payload;
  return (
    <div className="rounded-xl border bg-white px-3 py-2 text-xs shadow-sm">
      <p className="font-semibold text-gray-900">{p?.name}</p>
      <p className="text-gray-600">
        Bookings: <span className="font-semibold">{p?.value ?? 0}</span>
      </p>
    </div>
  );
}

function CustomBarTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border bg-white px-3 py-2 text-xs shadow-sm">
      <p className="font-semibold text-gray-900">{label}</p>
      <p className="text-gray-600">
        Revenue: <span className="font-semibold">₹{formatK(payload[0]?.value || 0)}</span>
      </p>
    </div>
  );
}

/** ---------- main ---------- */
export default function Dashboard() {
  const [range, setRange] = useState("week");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [counts, setCounts] = useState(null);
  const [charts, setCharts] = useState({
    revenueData: [],
    serviceData: [],
    cityData: [],
    topPartners: [],
  });

  const load = async (selectedRange = range) => {
    try {
      setLoading(true);
      setError("");

      const res = await getDashboardSummaryApi({ range: selectedRange });

      setCounts(res.data.counts);
      setCharts(res.data.charts);
    } catch (e) {
      setError(e?.response?.data?.message || "Failed to load dashboard");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load(range);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [range]);

  const c = counts || {
    totalBookings: 0,
    filteredBookings: 0,
    pendingBookings: 0,
    totalUsers: 0,
    activeServices: 0,
    totalRevenue: 0,
    totalServices: 0,
    activeOffers: 0,
  };

  const serviceData = useMemo(() => safeArray(charts?.serviceData), [charts]);
  const revenueData = useMemo(() => safeArray(charts?.revenueData), [charts]);
  const cityData = useMemo(() => safeArray(charts?.cityData), [charts]);
  const topPartners = useMemo(() => safeArray(charts?.topPartners), [charts]);

  const topServiceList = useMemo(() => {
    return [...serviceData]
      .map((x) => ({
        name: x?.name || "Service",
        value: Number(x?.value || 0),
      }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6);
  }, [serviceData]);

  const rangeLabel =
    range === "week" ? "This Week" : range === "month" ? "This Month" : "This Year";

  const stats = useMemo(() => {
    return [
      {
        title: "Total Services Booked",
        value: formatK(c.totalBookings),
        sub: `${rangeLabel}: ${formatK(c.filteredBookings || 0)}`,
        icon: <Briefcase />,
        trend: { direction: "up", value: "+20%" },
      },
      {
        title: "Active Users",
        value: formatK(c.totalUsers),
        sub: "Than last week",
        icon: <Users />,
        trend: { direction: "up", value: "+8%" },
      },
      {
        title: "Active Service Partners",
        value: formatK(c.activeServices),
        sub: "Than last week",
        icon: <Wrench />,
        trend: { direction: "down", value: "-16%" },
      },
      {
        title: "Total Revenue",
        value: "₹" + formatK(c.totalRevenue),
        sub: rangeLabel,
        icon: <IndianRupee />,
        trend: { direction: "up", value: "+48%" },
      },
    ];
  }, [c, rangeLabel]);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-extrabold text-gray-900">Dashboard</h1>
            <p className="mt-1 text-sm text-gray-500"></p>
          </div>

          <div className="flex items-center gap-3">
            <PillTabs
              value={range}
              onChange={setRange}
              items={[
                { label: "This Week", value: "week" },
                { label: "This Month", value: "month" },
                { label: "This Year", value: "year" },
              ]}
            />

            <button
              onClick={() => load(range)}
              className="inline-flex items-center gap-2 rounded-xl border bg-white px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50"
            >
              <RefreshCcw size={16} />
              Refresh
            </button>
          </div>
        </div>

        <div className="mt-4">
          {loading ? (
            <div className="text-sm text-gray-500">Loading…</div>
          ) : error ? (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {error}
            </div>
          ) : null}
        </div>

        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {stats.map((s, i) => (
            <StatCard
              key={i}
              title={s.title}
              value={s.value}
              sub={s.sub}
              icon={s.icon}
              trend={s.trend}
            />
          ))}
        </div>

        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card
            title="Top Performing Services"
            right={
              <PillTabs
                value={range}
                onChange={setRange}
                items={[
                  { label: "This Week", value: "week" },
                  { label: "This Month", value: "month" },
                  { label: "This Year", value: "year" },
                ]}
              />
            }
          >
            {loading ? (
              <div className="h-70 rounded-2xl bg-gray-100 animate-pulse" />
            ) : (
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div className="h-70">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={serviceData}
                        dataKey="value"
                        nameKey="name"
                        innerRadius={60}
                        outerRadius={90}
                        paddingAngle={3}
                      >
                        {serviceData.map((_, i) => (
                          <Cell key={i} fill={COLORS[i % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomPieTooltip />} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                <div className="rounded-2xl border bg-gray-50 p-4">
                  <p className="text-xs font-semibold text-gray-600">Services</p>

                  <div className="mt-3 space-y-3">
                    {topServiceList.length === 0 ? (
                      <p className="text-sm text-gray-500">No data</p>
                    ) : (
                      topServiceList.map((s, i) => (
                        <div key={s.name + i} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span
                              className="h-2.5 w-2.5 rounded-full"
                              style={{ background: COLORS[i % COLORS.length] }}
                            />
                            <p className="text-sm font-semibold text-gray-800">{s.name}</p>
                          </div>
                          <p className="text-sm font-extrabold text-gray-900">
                            {formatK(s.value)}
                            <span className="ml-1 text-xs font-semibold text-gray-500">
                              bookings
                            </span>
                          </p>
                        </div>
                      ))
                    )}
                  </div>

                  <div className="mt-4 rounded-xl border bg-white p-3 text-sm">
                    <p className="text-gray-600">
                      Total Bookings:{" "}
                      <span className="font-extrabold text-gray-900">
                        {formatK(c.totalBookings)}
                      </span>
                    </p>

                    <p className="mt-1 text-gray-600">
                      {rangeLabel}:{" "}
                      <span className="font-extrabold text-indigo-700">
                        {formatK(c.filteredBookings || 0)}
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            )}
          </Card>

          <Card
            title="Revenue Overview"
            right={
              <PillTabs
                value={range}
                onChange={setRange}
                items={[
                  { label: "This Week", value: "week" },
                  { label: "This Month", value: "month" },
                  { label: "This Year", value: "year" },
                ]}
              />
            }
          >
            {loading ? (
              <div className="h-70 rounded-2xl bg-gray-100 animate-pulse" />
            ) : (
              <div className="h-70">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" tickLine={false} axisLine={false} />
                    <YAxis tickLine={false} axisLine={false} />
                    <Tooltip content={<CustomBarTooltip />} />
                    <Bar dataKey="value" radius={[10, 10, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </Card>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card
            title="Top Cities by Bookings"
            right={
              <PillTabs
                value={range}
                onChange={setRange}
                items={[
                  { label: "This Week", value: "week" },
                  { label: "This Month", value: "month" },
                  { label: "This Year", value: "year" },
                ]}
              />
            }
          >
            {loading ? (
              <div className="h-70 rounded-2xl bg-gray-100 animate-pulse" />
            ) : (
              <div className="h-70">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={cityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" tickLine={false} axisLine={false} />
                    <YAxis tickLine={false} axisLine={false} />
                    <Tooltip />
                    <Line type="monotone" dataKey="Ahmedabad" strokeWidth={3} dot={false} />
                    <Line type="monotone" dataKey="Rajkot" strokeWidth={3} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </Card>

          <Card
            title="Top Service Partners"
            right={
              <button className="rounded-full border bg-white px-3 py-1.5 text-xs font-semibold text-indigo-700 hover:bg-gray-50">
                View All
              </button>
            }
          >
            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="h-12 rounded-xl bg-gray-100 animate-pulse" />
                ))}
              </div>
            ) : topPartners.length === 0 ? (
              <div className="rounded-xl border bg-gray-50 p-4 text-sm text-gray-600">
                No partner data found.
              </div>
            ) : (
              <div className="space-y-3">
                {topPartners.slice(0, 5).map((p, idx) => (
                  <div
                    key={p?._id || idx}
                    className="flex items-center justify-between rounded-2xl border bg-white p-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-2xl bg-indigo-50 grid place-items-center text-indigo-700 font-extrabold">
                        {(p?.name || "P")[0]?.toUpperCase()}
                      </div>
                      <div>
                        <p className="text-sm font-extrabold text-gray-900">
                          {p?.name || "Partner"}
                        </p>
                        <p className="text-xs text-gray-500">
                          {p?.category || "Service Partner"}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="text-sm font-extrabold text-gray-900">
                        {formatK(p?.completed || 0)}
                      </p>
                      <p className="text-xs text-gray-500">Completed</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-5 rounded-2xl border bg-gray-50 p-4">
              <p className="text-xs font-semibold text-gray-600">Quick Summary</p>
              <div className="mt-3 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Services</span>
                  <span className="font-extrabold text-gray-900">{formatK(c.totalServices ?? 0)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Active Offers</span>
                  <span className="font-extrabold text-gray-900">{formatK(c.activeOffers ?? 0)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Pending Bookings</span>
                  <span className="font-extrabold text-gray-900">{formatK(c.pendingBookings ?? 0)}</span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}