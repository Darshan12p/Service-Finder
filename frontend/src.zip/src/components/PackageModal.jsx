import React, { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getPackagesByServiceApi } from "../services/api";
import {
  X,
  Check,
  Loader2,
  Sparkles,
  Clock3,
  ArrowRight,
  Plus,
  Minus,
  ShieldCheck,
  BadgeCheck,
} from "lucide-react";

export default function PackageModal({
  open,
  setOpen,
  selectedService,
  redirectToBooking = true,
  onSelect,
}) {
  const navigate = useNavigate();
  const panelRef = useRef(null);

  const [apiPkgs, setApiPkgs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [activePkgKey, setActivePkgKey] = useState(null);
  const [selectedOptions, setSelectedOptions] = useState({});

  const close = () => setOpen(false);

  const memoPkgs = useMemo(() => {
    const arr = selectedService?.packages || [];
    if (!Array.isArray(arr)) return [];
    return [...arr].sort(
      (a, b) => Number(a?.sortOrder || 0) - Number(b?.sortOrder || 0)
    );
  }, [selectedService]);

  const pkgs = useMemo(() => {
    const list = apiPkgs?.length ? apiPkgs : memoPkgs;
    return Array.isArray(list) ? list : [];
  }, [apiPkgs, memoPkgs]);

  const activePkg = useMemo(() => {
    if (!pkgs.length) return null;
    return (
      pkgs.find((p) => (p?._id || p?.name) === activePkgKey) || pkgs[0] || null
    );
  }, [pkgs, activePkgKey]);

  const optionGroups = useMemo(() => {
    return Array.isArray(activePkg?.optionGroups) ? activePkg.optionGroups : [];
  }, [activePkg]);

  const normalizePkg = (pkg) => {
    return {
      ...pkg,
      name: pkg?.name || pkg?.title || pkg?.packageName || "Selected Package",
      basePrice:
        Number(pkg?.basePrice ?? pkg?.price ?? pkg?.amount ?? pkg?.cost ?? 0) || 0,
      durationMins: Number(pkg?.durationMins || 0) || 0,
    };
  };

  const getGroupId = (group, index) => group?._id || group?.name || `group-${index}`;
  const getOptionId = (opt, index) => opt?._id || opt?.label || `option-${index}`;

  const initializeSelections = (pkg) => {
    const groups = Array.isArray(pkg?.optionGroups) ? pkg.optionGroups : [];
    const initial = {};

    groups.forEach((group, groupIndex) => {
      const groupId = getGroupId(group, groupIndex);
      const options = Array.isArray(group?.options) ? group.options : [];
      const activeOptions = options.filter((opt) => opt?.isActive !== false);

      if (!activeOptions.length) {
        initial[groupId] = group?.type === "multiple" ? [] : null;
        return;
      }

      if (group?.type === "multiple") {
        initial[groupId] = [];
      } else {
        initial[groupId] = group?.isRequired
          ? activeOptions[0]?._id || activeOptions[0]?.label || null
          : null;
      }
    });

    setSelectedOptions(initial);
  };

  const isRecommended = (p, idx) => {
    const nm = String(p?.name || "").toLowerCase();
    return nm === "standard" || Number(p?.sortOrder ?? idx) === 1;
  };

  const toggleOption = (group, option, groupIndex, optionIndex) => {
    if (option?.isActive === false) return;

    const groupId = getGroupId(group, groupIndex);
    const optionId = getOptionId(option, optionIndex);

    setSelectedOptions((prev) => {
      const next = { ...prev };

      if (group?.type === "multiple") {
        const prevArr = Array.isArray(next[groupId]) ? next[groupId] : [];
        const exists = prevArr.includes(optionId);

        next[groupId] = exists
          ? prevArr.filter((id) => id !== optionId)
          : [...prevArr, optionId];
      } else {
        next[groupId] = optionId;
      }

      return next;
    });
  };

  const isOptionSelected = (group, option, groupIndex, optionIndex) => {
    const groupId = getGroupId(group, groupIndex);
    const optionId = getOptionId(option, optionIndex);
    const val = selectedOptions[groupId];

    if (group?.type === "multiple") {
      return Array.isArray(val) && val.includes(optionId);
    }

    return val === optionId;
  };

  const selectedOptionObjects = useMemo(() => {
    const output = [];

    optionGroups.forEach((group, groupIndex) => {
      const groupId = getGroupId(group, groupIndex);
      const options = Array.isArray(group?.options) ? group.options : [];
      const selected = selectedOptions[groupId];

      if (group?.type === "multiple") {
        const arr = Array.isArray(selected) ? selected : [];
        arr.forEach((selectedId) => {
          const found = options.find(
            (opt, idx) => getOptionId(opt, idx) === selectedId
          );
          if (found) {
            output.push({
              groupId,
              groupName: group?.name || "Options",
              ...found,
            });
          }
        });
      } else {
        const found = options.find(
          (opt, idx) => getOptionId(opt, idx) === selected
        );
        if (found) {
          output.push({
            groupId,
            groupName: group?.name || "Options",
            ...found,
          });
        }
      }
    });

    return output;
  }, [optionGroups, selectedOptions]);

  const totalPrice = useMemo(() => {
    if (!activePkg) return 0;

    const base =
      Number(
        activePkg?.basePrice ??
          activePkg?.price ??
          activePkg?.amount ??
          activePkg?.cost ??
          0
      ) || 0;

    const extra = selectedOptionObjects.reduce((sum, item) => {
      return sum + (Number(item?.price || 0) || 0);
    }, 0);

    return base + extra;
  }, [activePkg, selectedOptionObjects]);

  const missingRequiredGroups = useMemo(() => {
    return optionGroups.filter((group, groupIndex) => {
      if (!group?.isRequired) return false;

      const groupId = getGroupId(group, groupIndex);
      const value = selectedOptions[groupId];

      if (group?.type === "multiple") {
        return !Array.isArray(value) || value.length === 0;
      }

      return !value;
    });
  }, [optionGroups, selectedOptions]);

  const canContinue =
    !!activePkg &&
    activePkg?.isActive !== false &&
    missingRequiredGroups.length === 0;

  const handleContinue = () => {
    if (!activePkg || activePkg?.isActive === false) return;
    if (missingRequiredGroups.length > 0) return;

    const normalizedPkg = normalizePkg(activePkg);

    const finalSelection = {
      ...normalizedPkg,
      selectedOptions,
      selectedOptionObjects,
      finalPrice: totalPrice,
    };

    if (redirectToBooking) {
      if (!selectedService?._id) {
        alert("Service not found. Please select service again.");
        return;
      }

      navigate("/booking", {
        state: {
          serviceId: selectedService._id,
          selectedPkg: finalSelection,
        },
      });
      close();
      return;
    }

    onSelect?.(finalSelection);
    close();
  };

  useEffect(() => {
    if (!open) return;

    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const onKey = (e) => {
      if (e.key === "Escape") close();
    };

    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;

    const serviceId = selectedService?._id;
    if (!serviceId) {
      setApiPkgs([]);
      setActivePkgKey(null);
      setSelectedOptions({});
      return;
    }

    setLoading(true);
    setError("");

    getPackagesByServiceApi(serviceId)
      .then((res) => {
        const data = res?.data;
        const arr = Array.isArray(data) ? data : data?.packages || [];
        const list = Array.isArray(arr) ? [...arr] : [];

        list.sort(
          (a, b) => Number(a?.sortOrder || 0) - Number(b?.sortOrder || 0)
        );

        setApiPkgs(list);

        const defaultPkg =
          list.find((p) => String(p?.name || "").toLowerCase() === "standard") ||
          list.find((p) => p?.isActive !== false) ||
          list[0] ||
          null;

        const key = defaultPkg?._id || defaultPkg?.name || null;
        setActivePkgKey(key);

        if (defaultPkg) {
          initializeSelections(defaultPkg);
        } else {
          setSelectedOptions({});
        }
      })
      .catch((e) => {
        console.log("Packages fetch error:", e);
        setApiPkgs([]);
        setError("Failed to load packages. Please try again.");
      })
      .finally(() => setLoading(false));
  }, [open, selectedService?._id]);

  useEffect(() => {
    if (!activePkg) {
      setSelectedOptions({});
      return;
    }
    initializeSelections(activePkg);
  }, [activePkgKey]);

  if (!open) return null;

  const title = selectedService?.title || "Service Packages";

  const serviceImage = (() => {
    const raw =
      selectedService?.imageUrl ||
      selectedService?.image ||
      selectedService?.thumbnail ||
      "";
    if (!raw) return "";
    if (raw.startsWith("http")) return raw;
    const base = (import.meta.env.VITE_API_URL || "http://localhost:5000").replace(
      /\/$/,
      ""
    );
    return `${base}${raw}`;
  })();

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-4">
      <button
        className="absolute inset-0 bg-black/60 backdrop-blur-[2px]"
        onClick={close}
        aria-label="Close"
      />

      <div className="relative w-full max-w-5xl max-h-[94vh] overflow-hidden rounded-[30px] border border-slate-200 bg-white shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur px-4 py-4 sm:px-6 sm:py-5">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 truncate">
                {title}
              </h2>
              <p className="mt-1 text-sm text-slate-500">
                Pick a package and customize it for your needs
              </p>
            </div>

            <button
              onClick={close}
              className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl border border-slate-200 hover:bg-slate-50"
              aria-label="Close"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="max-h-[calc(94vh-160px)] overflow-y-auto">
          {loading ? (
            <div className="p-6">
              <div className="flex items-center gap-3 rounded-3xl border border-slate-200 bg-slate-50 p-6 text-slate-700">
                <Loader2 size={18} className="animate-spin" />
                Loading packages...
              </div>
            </div>
          ) : error ? (
            <div className="p-6">
              <div className="rounded-3xl border border-rose-200 bg-rose-50 p-6 text-rose-700">
                <p className="font-extrabold">Something went wrong</p>
                <p className="mt-1 text-sm">{error}</p>
              </div>
            </div>
          ) : pkgs.length === 0 ? (
            <div className="p-6">
              <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6 text-slate-700">
                No packages available for this service.
              </div>
            </div>
          ) : (
            <>
              {/* service banner */}
              <div className="border-b border-slate-200 bg-slate-50 px-4 py-4 sm:px-6 sm:py-5">
                <div className="flex items-center gap-4">
                  <div className="h-16 w-16 overflow-hidden rounded-2xl border border-slate-200 bg-white shrink-0">
                    {serviceImage ? (
                      <img
                        src={serviceImage}
                        alt={title}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="grid h-full w-full place-items-center text-xs font-bold text-slate-500">
                        SF
                      </div>
                    )}
                  </div>

                  <div className="min-w-0">
                    <p className="text-sm font-bold text-indigo-600">
                      Service selected
                    </p>
                    <h3 className="truncate text-lg font-black text-slate-900">
                      {title}
                    </h3>
                    <div className="mt-1 flex flex-wrap gap-2">
                      <span className="inline-flex items-center gap-1 rounded-full bg-white px-3 py-1 text-xs font-bold text-slate-700 border border-slate-200">
                        <ShieldCheck size={12} className="text-emerald-600" />
                        Verified Service
                      </span>
                      <span className="inline-flex items-center gap-1 rounded-full bg-white px-3 py-1 text-xs font-bold text-slate-700 border border-slate-200">
                        <BadgeCheck size={12} className="text-indigo-600" />
                        Customizable Packages
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* top package tabs */}
              <div className="border-b border-slate-200 px-4 py-4 sm:px-6">
                <div className="flex gap-3 overflow-x-auto pb-1">
                  {pkgs.map((p, idx) => {
                    const key = p?._id || p?.name || `pkg-${idx}`;
                    const selected = key === activePkgKey;
                    const name =
                      p?.name || p?.title || p?.packageName || `Package ${idx + 1}`;
                    const price = Number(
                      p?.basePrice ?? p?.price ?? p?.amount ?? p?.cost ?? 0
                    );
                    const inactive = p?.isActive === false;
                    const rec = isRecommended(p, idx);

                    return (
                      <button
                        key={key}
                        type="button"
                        disabled={inactive}
                        onClick={() => {
                          if (inactive) return;
                          setActivePkgKey(key);
                        }}
                        className={[
                          "min-w-[150px] shrink-0 rounded-2xl border p-4 text-left transition",
                          selected
                            ? "border-indigo-600 bg-indigo-50 ring-2 ring-indigo-100"
                            : "border-slate-200 bg-white hover:bg-slate-50",
                          inactive ? "opacity-50 cursor-not-allowed" : "",
                        ].join(" ")}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="text-sm font-black text-slate-900">
                              {name}
                            </p>
                            <p className="mt-1 text-lg font-black text-indigo-700">
                              ₹{price}
                            </p>
                          </div>

                          {rec ? (
                            <span className="rounded-full bg-indigo-600 px-2 py-1 text-[10px] font-extrabold text-white">
                              Popular
                            </span>
                          ) : null}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* content */}
              <div className="p-4 sm:p-6">
                {activePkg ? (
                  <>
                    {/* package summary card */}
                    <div className="rounded-[28px] border border-slate-200 bg-slate-50 p-5 sm:p-6">
                      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                        <div>
                          <p className="text-xs font-bold uppercase tracking-wide text-indigo-600">
                            Selected package
                          </p>
                          <h3 className="mt-2 text-2xl font-black text-slate-900">
                            {activePkg?.name || "Selected Package"}
                          </h3>

                          {activePkg?.description ? (
                            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
                              {activePkg.description}
                            </p>
                          ) : null}

                          <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-700">
                            <Clock3 size={14} className="text-indigo-600" />
                            {Number(activePkg?.durationMins || 0)
                              ? `${Number(activePkg?.durationMins)} mins`
                              : "Duration N/A"}
                          </div>
                        </div>

                        <div className="rounded-2xl border border-slate-200 bg-white px-5 py-4 text-right shadow-sm">
                          <p className="text-xs font-bold uppercase tracking-wide text-slate-500">
                            Total
                          </p>
                          <p className="mt-1 text-3xl font-black text-indigo-700">
                            ₹{totalPrice}
                          </p>
                        </div>
                      </div>

                      {Array.isArray(activePkg?.features) &&
                      activePkg.features.length ? (
                        <div className="mt-5">
                          <p className="text-sm font-black text-slate-900">
                            What’s included
                          </p>

                          <div className="mt-3 grid gap-3 sm:grid-cols-2">
                            {activePkg.features.map((f, i) => (
                              <div
                                key={i}
                                className="flex items-start gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700"
                              >
                                <span className="mt-0.5 text-emerald-600">
                                  <Check size={16} />
                                </span>
                                <span>{f}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : null}
                    </div>

                    {/* options */}
                    <div className="mt-6 space-y-6">
                      {optionGroups.length > 0 ? (
                        optionGroups.map((group, groupIndex) => {
                          const groupId = getGroupId(group, groupIndex);
                          const options = Array.isArray(group?.options)
                            ? group.options
                            : [];

                          return (
                            <div
                              key={groupId}
                              className="rounded-[28px] border border-slate-200 bg-white p-5 sm:p-6"
                            >
                              <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                  <h4 className="text-lg font-black text-slate-900">
                                    {group?.name || `Group ${groupIndex + 1}`}
                                  </h4>
                                  <p className="mt-1 text-xs font-semibold text-slate-500">
                                    {group?.type === "multiple"
                                      ? "Select one or more options"
                                      : "Select one option"}
                                    {group?.isRequired ? " • Required" : " • Optional"}
                                  </p>
                                </div>
                              </div>

                              {options.length === 0 ? (
                                <div className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-500">
                                  No options added yet.
                                </div>
                              ) : (
                                <div className="grid gap-3 sm:grid-cols-2">
                                  {options.map((opt, optionIndex) => {
                                    const selected = isOptionSelected(
                                      group,
                                      opt,
                                      groupIndex,
                                      optionIndex
                                    );
                                    const inactive = opt?.isActive === false;
                                    const extraPrice =
                                      Number(opt?.price || 0) || 0;

                                    return (
                                      <button
                                        key={getOptionId(opt, optionIndex)}
                                        type="button"
                                        disabled={inactive}
                                        onClick={() =>
                                          toggleOption(group, opt, groupIndex, optionIndex)
                                        }
                                        className={[
                                          "w-full rounded-2xl border p-4 text-left transition-all",
                                          selected
                                            ? "border-indigo-600 bg-indigo-50 ring-2 ring-indigo-100"
                                            : "border-slate-200 bg-white hover:shadow-sm",
                                          inactive ? "opacity-50 cursor-not-allowed" : "",
                                        ].join(" ")}
                                      >
                                        <div className="flex items-start justify-between gap-3">
                                          <div className="min-w-0">
                                            <p className="text-sm font-black text-slate-900">
                                              {opt?.label ||
                                                opt?.name ||
                                                `Option ${optionIndex + 1}`}
                                            </p>

                                            {opt?.description ? (
                                              <p className="mt-1 text-xs leading-5 text-slate-500">
                                                {opt.description}
                                              </p>
                                            ) : null}
                                          </div>

                                          <div
                                            className={[
                                              "grid h-8 w-8 shrink-0 place-items-center rounded-xl border",
                                              selected
                                                ? "border-indigo-600 bg-indigo-600 text-white"
                                                : "border-slate-200 bg-white text-transparent",
                                            ].join(" ")}
                                          >
                                            <Check size={16} />
                                          </div>
                                        </div>

                                        <div className="mt-4 flex items-center justify-between">
                                          <div className="text-sm font-black text-indigo-700">
                                            {extraPrice > 0
                                              ? `+ ₹${extraPrice}`
                                              : "Included"}
                                          </div>

                                          {group?.type === "multiple" ? (
                                            <div className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-bold text-slate-600">
                                              {selected ? (
                                                <>
                                                  <Minus size={14} />
                                                  Added
                                                </>
                                              ) : (
                                                <>
                                                  <Plus size={14} />
                                                  Add
                                                </>
                                              )}
                                            </div>
                                          ) : (
                                            <div className="text-xs font-semibold text-slate-500">
                                              {selected ? "Selected" : "Tap to select"}
                                            </div>
                                          )}
                                        </div>
                                      </button>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          );
                        })
                      ) : (
                        <div className="rounded-[28px] border border-dashed border-slate-300 p-6 text-sm text-slate-500">
                          No customization options added for this package yet.
                        </div>
                      )}
                    </div>

                    {/* summary */}
                    <div className="mt-6 rounded-[28px] border border-slate-200 bg-slate-50 p-5 sm:p-6">
                      <p className="text-lg font-black text-slate-900">
                        Selection summary
                      </p>

                      <div className="mt-4 space-y-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-slate-600">Base Package</span>
                          <span className="font-black text-slate-900">
                            ₹
                            {Number(
                              activePkg?.basePrice ??
                                activePkg?.price ??
                                activePkg?.amount ??
                                activePkg?.cost ??
                                0
                            ) || 0}
                          </span>
                        </div>

                        {selectedOptionObjects.map((item, idx) => (
                          <div
                            key={`${item?.groupId}-${item?._id || item?.label || idx}`}
                            className="flex items-center justify-between text-sm"
                          >
                            <span className="text-slate-600">
                              {item?.groupName}: {item?.label || item?.name}
                            </span>
                            <span className="font-bold text-slate-900">
                              {Number(item?.price || 0) > 0
                                ? `₹${Number(item?.price || 0)}`
                                : "Included"}
                            </span>
                          </div>
                        ))}

                        <div className="mt-4 border-t border-slate-200 pt-4 flex items-center justify-between">
                          <span className="text-base font-black text-slate-900">
                            Final Total
                          </span>
                          <span className="text-3xl font-black text-indigo-700">
                            ₹{totalPrice}
                          </span>
                        </div>
                      </div>
                    </div>

                    {missingRequiredGroups.length > 0 ? (
                      <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
                        Please select required option(s):{" "}
                        <span className="font-black">
                          {missingRequiredGroups
                            .map((g) => g?.name)
                            .filter(Boolean)
                            .join(", ")}
                        </span>
                      </div>
                    ) : null}
                  </>
                ) : (
                  <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6 text-slate-600">
                    Please select a package.
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        {/* footer */}
        <div className="sticky bottom-0 z-30 border-t border-slate-200 bg-white/95 backdrop-blur px-4 py-4 sm:px-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-wide text-slate-500">
                Current selection
              </p>
              <p className="mt-1 text-sm font-black text-slate-900">
                {activePkg
                  ? `${activePkg?.name || "Package"} • ₹${totalPrice}`
                  : "No package selected"}
              </p>
            </div>

            <div className="flex gap-2">
              <button
                onClick={close}
                className="rounded-2xl border border-slate-200 px-5 py-3 font-black text-slate-800 hover:bg-slate-50"
              >
                Close
              </button>

              <button
                onClick={handleContinue}
                disabled={!canContinue}
                className={[
                  "inline-flex items-center gap-2 rounded-2xl px-5 py-3 font-black text-white transition",
                  canContinue
                    ? "bg-indigo-600 hover:bg-indigo-700"
                    : "cursor-not-allowed bg-slate-300",
                ].join(" ")}
              >
                Continue <ArrowRight size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}