import { useEffect, useRef, useState } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { Menu, X, User, CalendarDays, LogOut, LayoutDashboard } from "lucide-react";

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [open, setOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const menuRef = useRef(null);

  const syncUser = () => {
    try {
      const raw = localStorage.getItem("user");
      setUser(raw ? JSON.parse(raw) : null);
    } catch {
      setUser(null);
    }
  };

  useEffect(() => {
    syncUser();
  }, []);

  useEffect(() => {
    syncUser();
    setUserMenuOpen(false);
    setOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handler = () => syncUser();
    window.addEventListener("authChanged", handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener("authChanged", handler);
      window.removeEventListener("storage", handler);
    };
  }, []);

  useEffect(() => {
    const handler = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setUserMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("userToken");
    localStorage.removeItem("user");
    setUser(null);
    setUserMenuOpen(false);
    window.dispatchEvent(new Event("authChanged"));
    navigate("/");
  };

  const linkClass = ({ isActive }) =>
    `relative px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
      isActive
        ? "text-indigo-700 bg-indigo-50 shadow-sm"
        : "text-gray-700 hover:text-indigo-700 hover:bg-white/80"
    }`;

  const displayName =
    user?.name || user?.fullName || user?.username || user?.email || "User";

  const initials = displayName
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("");

  const goMyBookings = () => {
    setUserMenuOpen(false);
    setOpen(false);

    const raw = localStorage.getItem("user");
    if (!raw) return navigate("/sign");

    navigate("/my-bookings");
  };

  return (
    <header className="sticky top-0 z-50 border-b border-white/30 bg-white/75 backdrop-blur-xl shadow-sm">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-3 flex items-center justify-between">
        {/* Logo */}
        <button onClick={() => navigate("/")} className="flex items-center gap-3 group">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-600 text-white grid place-items-center font-extrabold shadow-lg group-hover:scale-105 transition">
            SF
          </div>
          <div className="text-left">
            <p className="text-lg sm:text-xl font-extrabold tracking-tight text-gray-900">
              Service Finder
            </p>
            <p className="text-xs text-gray-500 -mt-0.5">Trusted doorstep services</p>
          </div>
        </button>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-2 rounded-full bg-gray-50/80 p-1.5 border border-gray-100">
          <NavLink to="/" className={linkClass}>
            Home
          </NavLink>
          <NavLink to="/services" className={linkClass}>
            Services
          </NavLink>
          <NavLink to="/contact" className={linkClass}>
            Contact Us
          </NavLink>
        </div>

        {/* Desktop right */}
        <div className="hidden md:flex items-center gap-3">
          {!user ? (
            <button
              onClick={() => navigate("/sign")}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white px-5 py-2.5 rounded-full text-sm font-semibold shadow-md hover:shadow-lg transition-all"
            >
              Sign In
            </button>
          ) : (
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setUserMenuOpen((p) => !p)}
                className="flex items-center gap-3 px-3 py-2 rounded-2xl border border-gray-200 bg-white shadow-sm hover:shadow-md transition-all"
              >
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 text-white grid place-items-center font-bold text-sm shadow">
                  {initials || "U"}
                </div>

                <div className="text-left leading-tight">
                  <div className="text-sm font-semibold text-gray-900 max-w-40 truncate">
                    {displayName}
                  </div>
                  <div className="text-xs text-gray-500">Welcome back</div>
                </div>

                <span className="text-gray-400 text-sm">▾</span>
              </button>

              {userMenuOpen && (
                <div className="absolute right-0 mt-3 w-60 bg-white/95 backdrop-blur-xl border border-gray-100 rounded-2xl shadow-2xl overflow-hidden">
                  <button
                    onClick={goMyBookings}
                    className="w-full flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-indigo-50 transition"
                  >
                    <CalendarDays size={18} />
                    My Bookings
                  </button>

                  <button
                    onClick={() => {
                      setUserMenuOpen(false);
                      navigate("/profile");
                    }}
                    className="w-full flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-indigo-50 transition"
                  >
                    <User size={18} />
                    Profile
                  </button>

                  {/* <button
                    onClick={() => {
                      setUserMenuOpen(false);
                      navigate("/dashboard");
                    }}
                    className="w-full flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-indigo-50 transition"
                  >
                    <LayoutDashboard size={18} />
                    Dashboard
                  </button> */}

                  <div className="h-px bg-gray-100" />

                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-4 py-3 text-sm text-red-600 hover:bg-red-50 transition"
                  >
                    <LogOut size={18} />
                    Logout
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Mobile button */}
        <button
          className="md:hidden w-11 h-11 rounded-2xl border border-gray-200 bg-white shadow-sm flex items-center justify-center"
          onClick={() => setOpen((p) => !p)}
          aria-label="menu"
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-gray-100 bg-white/95 backdrop-blur-xl">
          <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col gap-2">
            <NavLink onClick={() => setOpen(false)} to="/" className={linkClass}>
              Home
            </NavLink>
            <NavLink onClick={() => setOpen(false)} to="/services" className={linkClass}>
              Services
            </NavLink>
            <NavLink onClick={() => setOpen(false)} to="/contact" className={linkClass}>
              Contact Us
            </NavLink>

            {user && (
              <>
                <button
                  onClick={goMyBookings}
                  className="px-4 py-3 rounded-2xl text-sm font-medium text-left text-gray-700 hover:bg-indigo-50"
                >
                  My Bookings
                </button>
                <button
                  onClick={() => {
                    setOpen(false);
                    navigate("/profile");
                  }}
                  className="px-4 py-3 rounded-2xl text-sm font-medium text-left text-gray-700 hover:bg-indigo-50"
                >
                  Profile
                </button>
              </>
            )}

            {!user ? (
              <button
                onClick={() => {
                  setOpen(false);
                  navigate("/sign");
                }}
                className="mt-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-5 py-3 rounded-2xl text-sm font-semibold shadow"
              >
                Sign In
              </button>
            ) : (
              <button
                onClick={() => {
                  setOpen(false);
                  handleLogout();
                }}
                className="mt-2 bg-red-600 hover:bg-red-700 text-white px-5 py-3 rounded-2xl text-sm font-semibold shadow"
              >
                Logout
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;