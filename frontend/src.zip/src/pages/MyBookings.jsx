import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getMyBookingsApi } from "../services/api";
import { jsPDF } from "jspdf";
import {
  Calendar,
  Clock,
  MapPin,
  CreditCard,
  Search,
  ArrowUpDown,
  Home,
  Download,
  UserCheck,
  Phone,
} from "lucide-react";

/* ---------------- helpers ---------------- */

const badge = (status) => {
  const base = "px-3 py-1 rounded-full text-xs font-bold border";

  if (status === "Completed")
    return `${base} bg-green-50 text-green-700 border-green-200`;

  if (status === "Confirmed")
    return `${base} bg-blue-50 text-blue-700 border-blue-200`;

  if (status === "Cancelled")
    return `${base} bg-red-50 text-red-700 border-red-200`;

  return `${base} bg-yellow-50 text-yellow-700 border-yellow-200`;
};

const assignmentBadge = (status) => {
  const base = "px-3 py-1 rounded-full text-xs font-bold border";

  if (status === "Accepted")
    return `${base} bg-green-50 text-green-700 border-green-200`;

  if (status === "Assigned")
    return `${base} bg-indigo-50 text-indigo-700 border-indigo-200`;

  if (status === "Reassigned")
    return `${base} bg-violet-50 text-violet-700 border-violet-200`;

  if (status === "Rejected")
    return `${base} bg-red-50 text-red-700 border-red-200`;

  return `${base} bg-slate-50 text-slate-700 border-slate-200`;
};

const safe = (v, fallback = "—") => (v ? v : fallback);

const formatDate = (ymd) => {
  if (!ymd) return "—";
  const d = new Date(ymd);
  if (String(d) === "Invalid Date") return ymd;
  return d.toLocaleDateString(undefined, {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

/* ---------------- page ---------------- */

export default function MyBookings() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [bookings, setBookings] = useState([]);

  const [tab, setTab] = useState("All");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState("newest");

  const user = JSON.parse(localStorage.getItem("user") || "null");
  const userId = user?._id;

  /* ---------------- fetch ---------------- */

  useEffect(() => {
    if (!userId) {
      navigate("/sign");
      return;
    }

    (async () => {
      try {
        setLoading(true);

        const apiTab =
          tab === "Completed"
            ? "completed"
            : tab === "Incomplete"
            ? "incomplete"
            : "all";

        const res = await getMyBookingsApi(userId, apiTab);
        setBookings(res?.data?.items || []);
      } catch (e) {
        navigate("/sign");
      } finally {
        setLoading(false);
      }
    })();
  }, [navigate, userId, tab]);

  /* ---------------- counts ---------------- */

  const counts = useMemo(() => {
    const all = bookings.length;

    const completed = bookings.filter(
      (b) => b.bookingStatus === "Completed"
    ).length;

    const incomplete = bookings.filter(
      (b) => b.bookingStatus !== "Completed"
    ).length;

    return { all, completed, incomplete };
  }, [bookings]);

  /* ---------------- filter + sort ---------------- */

  const filtered = useMemo(() => {
    let list = [...bookings];

    if (tab === "Completed") {
      list = list.filter((b) => b.bookingStatus === "Completed");
    }

    if (tab === "Incomplete") {
      list = list.filter((b) => b.bookingStatus !== "Completed");
    }

    const s = q.trim().toLowerCase();

    if (s) {
      list = list.filter((b) => {
        const title = (b.serviceTitle || "").toLowerCase();
        const pkg = (b.packageName || "").toLowerCase();
        const addr = (b?.address?.line1 || "").toLowerCase();
        const partner = (b.assignedPartnerName || "").toLowerCase();

        return (
          title.includes(s) ||
          pkg.includes(s) ||
          addr.includes(s) ||
          partner.includes(s)
        );
      });
    }

    list.sort((a, b) => {
      const da = new Date(a?.createdAt || 0).getTime();
      const db = new Date(b?.createdAt || 0).getTime();

      return sort === "oldest" ? da - db : db - da;
    });

    return list;
  }, [bookings, tab, q, sort]);

  /* ---------------- receipt ---------------- */

  const downloadReceipt = (b) => {
    const doc = new jsPDF();

    doc.setFontSize(18);
    doc.text("Service Finder Receipt", 14, 20);

    doc.setFontSize(11);

    doc.text(`Service: ${safe(b.serviceTitle)}`, 14, 40);
    doc.text(`Package: ${safe(b.packageName)}`, 14, 48);
    doc.text(`Amount: ₹${safe(b.packagePrice)}`, 14, 56);

    doc.text(`Date: ${formatDate(b?.slot?.date)}`, 14, 64);
    doc.text(`Time: ${safe(b?.slot?.time)}`, 14, 72);

    doc.text(`Address: ${safe(b?.address?.line1)}`, 14, 80);

    if (b.assignedPartnerName) {
      doc.text(`Assigned Partner: ${safe(b.assignedPartnerName)}`, 14, 88);
    }

    if (b.assignedPartnerPhone) {
      doc.text(`Partner Phone: ${safe(b.assignedPartnerPhone)}`, 14, 96);
    }

    doc.save("receipt.pdf");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white">
      <div className="max-w-5xl mx-auto px-4 py-6">
        {/* HEADER */}

        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-sm text-gray-500">Welcome back</p>

            <h1 className="text-2xl font-extrabold">My Bookings</h1>

            <p className="text-sm text-gray-500 mt-1">
              All: {counts.all} • Incomplete: {counts.incomplete} • Completed: {counts.completed}
            </p>
          </div>

          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 border px-4 py-2 rounded-xl hover:bg-gray-50"
          >
            <Home size={16} />
            Home
          </button>
        </div>

        {/* FILTER BAR */}

        <div className="flex flex-col md:flex-row gap-3 mb-6">
          <div className="flex gap-2 flex-wrap">
            {["All", "Incomplete", "Completed"].map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-4 py-2 rounded-xl text-sm font-semibold ${
                  tab === t
                    ? "bg-indigo-600 text-white"
                    : "border hover:bg-gray-50"
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          <div className="flex gap-3 ml-auto flex-wrap">
            <div className="flex items-center border rounded-xl px-3 py-2 gap-2">
              <Search size={16} />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search booking"
                className="outline-none text-sm"
              />
            </div>

            <div className="flex items-center border rounded-xl px-3 py-2 gap-2">
              <ArrowUpDown size={16} />
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="outline-none text-sm"
              >
                <option value="newest">Newest</option>
                <option value="oldest">Oldest</option>
              </select>
            </div>
          </div>
        </div>

        {/* BOOKINGS */}

        {loading ? (
          <p className="text-gray-500">Loading...</p>
        ) : filtered.length === 0 ? (
          <div className="border rounded-xl p-6 text-center">
            <p className="text-gray-600">No bookings found</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filtered.map((b) => (
              <div
                key={b._id}
                className="border rounded-2xl p-5 bg-white shadow-sm hover:shadow-md transition"
              >
                {/* top */}

                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-3">
                  <div>
                    <p className="text-lg font-bold">{safe(b.serviceTitle)}</p>

                    <p className="text-sm text-gray-500">
                      {safe(b.serviceCategory)}
                    </p>
                  </div>

                  <span className={badge(b.bookingStatus)}>
                    {safe(b.bookingStatus)}
                  </span>
                </div>

                {/* info */}

                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div className="flex gap-2 items-center">
                    <Calendar size={16} />
                    {formatDate(b?.slot?.date)}
                  </div>

                  <div className="flex gap-2 items-center">
                    <Clock size={16} />
                    {safe(b?.slot?.time)}
                  </div>

                  <div className="flex gap-2 items-center">
                    <CreditCard size={16} />
                    ₹{safe(b.packagePrice)}
                  </div>

                  <div className="flex gap-2 items-center md:col-span-3">
                    <MapPin size={16} />
                    {safe(b?.address?.line1)}
                  </div>
                </div>

                {/* assigned partner */}

                {b.assignedPartnerId ? (
                  <div className="mt-4 rounded-2xl border bg-indigo-50/40 p-4">
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <UserCheck size={16} className="text-indigo-600" />
                      <p className="text-sm font-bold text-gray-900">
                        Assigned Service Partner
                      </p>

                      <span className={assignmentBadge(b.assignmentStatus)}>
                        {safe(b.assignmentStatus, "Assigned")}
                      </span>
                    </div>

                    <div className="grid md:grid-cols-2 gap-3 text-sm">
                      <div>
                        <span className="font-semibold text-gray-700">Name: </span>
                        <span className="text-gray-600">
                          {safe(b.assignedPartnerName)}
                        </span>
                      </div>

                      {b.assignedPartnerPhone ? (
                        <div className="flex items-center gap-2">
                          <Phone size={14} className="text-gray-500" />
                          <span className="text-gray-600">
                            {safe(b.assignedPartnerPhone)}
                          </span>
                        </div>
                      ) : null}
                    </div>
                  </div>
                ) : (
                  <div className="mt-4 rounded-2xl border bg-yellow-50 p-4 text-sm text-yellow-800">
                    Service partner has not been assigned yet.
                  </div>
                )}

                {/* actions */}

                <div className="flex flex-wrap gap-3 mt-4">
                  <button
                    onClick={() =>
                      navigate("/booking-confirmed", {
                        state: { booking: b },
                      })
                    }
                    className="border px-4 py-2 rounded-xl hover:bg-gray-50"
                  >
                    View
                  </button>

                  <button
                    onClick={() => downloadReceipt(b)}
                    className="flex items-center gap-2 border px-4 py-2 rounded-xl text-indigo-600"
                  >
                    <Download size={16} />
                    Receipt
                  </button>

                  <button
                    onClick={() => navigate("/services")}
                    className="bg-indigo-600 text-white px-4 py-2 rounded-xl hover:bg-indigo-700"
                  >
                    Book Again
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}