import React, { useEffect, useState } from "react";
import { getLatestReviewsApi } from "../services/api";
import StarRating from "../components/StarRating";
import { useNavigate } from "react-router-dom";

export default function AllReviews() {
  const [items, setItems] = useState([]);
  const [limit, setLimit] = useState(10);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const navigate = useNavigate();

  const load = async (lim = 10) => {
    try {
      setErr("");
      setLoading(true);
      const res = await getLatestReviewsApi(lim);
      setItems(res.data.items || []);
    } catch (e) {
      setErr(e?.response?.data?.message || "Failed to load reviews");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load(10);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-4xl px-4 py-10">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h1 className="text-3xl font-extrabold text-slate-900">All Reviews</h1>
            <p className="mt-1 text-sm text-slate-500">
              See what customers are saying.
            </p>
          </div>
          <button
            onClick={() => navigate(-1)}
            className="rounded-xl border bg-white px-4 py-2 text-sm font-bold hover:bg-slate-50"
          >
            ← Back
          </button>
        </div>

        {err && (
          <div className="mt-5 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            {err}
          </div>
        )}

        {loading ? (
          <p className="mt-6 text-sm text-slate-500">Loading...</p>
        ) : items.length === 0 ? (
          <p className="mt-6 text-sm text-slate-500">No reviews yet.</p>
        ) : (
          <div className="mt-6 space-y-4">
            {items.map((r) => (
              <div key={r._id} className="rounded-2xl border bg-white p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm font-extrabold text-slate-900">
                      {r?.serviceId?.title || "Service"}
                    </p>

                    <p className="mt-2 text-sm text-slate-800">{r.comment}</p>

                    <p className="mt-2 text-xs text-slate-400">
                      {new Date(r.createdAt).toLocaleString()}
                    </p>
                  </div>

                  <div className="flex flex-col items-end gap-2">
                    <StarRating value={r.rating} readOnly />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-8 flex items-center justify-center gap-3">
          <button
            disabled={loading || limit <= 10}
            onClick={() => {
              const next = Math.max(10, limit - 10);
              setLimit(next);
              load(next);
            }}
            className="rounded-xl border bg-white px-4 py-2 text-sm font-bold disabled:opacity-50"
          >
            Show less
          </button>

          <button
            disabled={loading}
            onClick={() => {
              const next = limit + 10;
              setLimit(next);
              load(next);
            }}
            className="rounded-xl bg-indigo-600 px-5 py-2 text-sm font-bold text-white hover:bg-indigo-700 disabled:opacity-60"
          >
            Load more
          </button>
        </div>
      </div>
    </div>
  );
}