import React from "react";
import { useNavigate } from "react-router-dom";

export default function Careers() {
  const navigate = useNavigate();

  const roles = [
    { title: "Customer Support Executive", type: "Full-time", location: "Ahmedabad" },
    { title: "Frontend Developer (React)", type: "Internship", location: "Remote" },
    { title: "Operations Coordinator", type: "Full-time", location: "Ahmedabad" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto bg-white border rounded-3xl p-6 shadow-sm">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-extrabold text-gray-900">Careers</h1>
            <p className="text-gray-600 mt-1">
              Join our team to build better services for everyone.
            </p>
          </div>
          <button
            onClick={() => navigate(-1)}
            className="px-4 py-2 rounded-xl border font-semibold hover:bg-gray-50"
          >
            Back
          </button>
        </div>

        <div className="mt-6 grid gap-4">
          {roles.map((r) => (
            <div key={r.title} className="border rounded-2xl p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-bold text-gray-900">{r.title}</p>
                  <p className="text-sm text-gray-600 mt-1">
                    {r.type} • {r.location}
                  </p>
                </div>
                <button className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm">
                  Apply
                </button>
              </div>
            </div>
          ))}
        </div>

        <p className="text-sm text-gray-500 mt-6">
          Send resume to: careers@servicefinder.com
        </p>
      </div>
    </div>
  );
}
