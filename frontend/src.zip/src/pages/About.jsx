import React from "react";
import { useNavigate } from "react-router-dom";

export default function About() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto bg-white border rounded-3xl p-6 shadow-sm">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-extrabold text-gray-900">About Us</h1>
            <p className="text-gray-600 mt-1">
              Service Finder connects customers with verified service partners.
            </p>
          </div>
          <button
            onClick={() => navigate(-1)}
            className="px-4 py-2 rounded-xl border font-semibold hover:bg-gray-50"
          >
            Back
          </button>
        </div>

        <div className="mt-6 space-y-4 text-gray-700 leading-relaxed">
          <p>
            We help you book trusted doorstep services like cleaning, plumbing,
            electrical work, appliance repair, and more — all from one place.
          </p>

          <div className="grid sm:grid-cols-3 gap-3">
            {[
              { t: "Verified Partners", d: "Only approved partners get listed." },
              { t: "Safe Booking", d: "Transparent pricing + schedules." },
              { t: "Support", d: "Quick help for any issue." },
            ].map((x) => (
              <div key={x.t} className="border rounded-2xl p-4 bg-gray-50">
                <p className="font-bold text-gray-900">{x.t}</p>
                <p className="text-sm text-gray-600 mt-1">{x.d}</p>
              </div>
            ))}
          </div>

          <p className="text-sm text-gray-500">
            For partnerships or business queries, email: support@servicefinder.com
          </p>
        </div>
      </div>
    </div>
  );
}
