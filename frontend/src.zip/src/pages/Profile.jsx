import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getMyProfileApi, updateMyProfileApi } from "../services/api";

export default function Profile() {
  const navigate = useNavigate();

  const localUser = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem("user") || "null");
    } catch {
      return null;
    }
  }, []);

  const userId = localUser?._id;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState(null);

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // ✅ Fetch fresh profile from DB
  useEffect(() => {
    if (!userId) {
      navigate("/sign");
      return;
    }

    (async () => {
      try {
        setLoading(true);
        setError("");
        const res = await getMyProfileApi(userId);
        const u = res.data.user;

        setProfile(u);
        setName(u.name || u.fullName || "");
        setPhone(u.phone || "");
      } catch (e) {
        setError(e?.response?.data?.message || "Failed to load profile");
      } finally {
        setLoading(false);
      }
    })();
  }, [navigate, userId]);

  const initials = (profile?.name || profile?.email || "U")
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("");

  const handleSave = async () => {
    try {
      setSaving(true);
      setError("");
      setSuccess("");

      if (!name.trim()) {
        setError("Name is required");
        return;
      }

      const res = await updateMyProfileApi(userId, {
        name: name.trim(),
        phone: phone.trim(),
      });

      setProfile(res.data.user);
      setSuccess("Profile updated successfully ✅");

      // ✅ update localStorage user also (so navbar name updates)
      localStorage.setItem("user", JSON.stringify(res.data.user));
      window.dispatchEvent(new Event("authChanged"));
    } catch (e) {
      setError(e?.response?.data?.message || "Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-3xl mx-auto bg-white border rounded-3xl p-6">
          Loading profile...
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-3xl mx-auto bg-white border rounded-3xl p-6">
          <p className="font-semibold text-gray-900">Profile not found</p>
          <button
            onClick={() => navigate("/")}
            className="mt-4 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold"
          >
            Go Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white border rounded-3xl p-6 shadow-sm">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="text-2xl font-extrabold text-gray-900">My Profile</h1>
              <p className="text-gray-600 mt-1">Manage your account details</p>
            </div>

            <button
              onClick={() => navigate("/")}
              className="px-4 py-2 rounded-xl border bg-white font-semibold hover:bg-gray-50"
            >
              Back Home
            </button>
          </div>

          {/* Header card */}
          <div className="mt-6 flex items-center gap-4 p-4 rounded-2xl border bg-gray-50">
            <div className="w-14 h-14 rounded-full bg-indigo-600 text-white grid place-items-center font-extrabold text-lg">
              {initials || "U"}
            </div>
            <div className="min-w-0">
              <p className="text-lg font-extrabold text-gray-900 truncate">
                {profile.name || profile.fullName || "User"}
              </p>
              <p className="text-sm text-gray-600 truncate">{profile.email}</p>
              <p className="text-xs text-gray-500 mt-1">
                Role: {profile.role || "customer"} • Verified: {profile.isVerified ? "Yes" : "No"}
              </p>
            </div>
          </div>

          {/* Messages */}
          {error ? (
            <div className="mt-4 p-3 rounded-xl bg-red-50 text-red-700 border border-red-200 text-sm">
              {error}
            </div>
          ) : null}

          {success ? (
            <div className="mt-4 p-3 rounded-xl bg-green-50 text-green-700 border border-green-200 text-sm">
              {success}
            </div>
          ) : null}

          {/* Form */}
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="text-sm font-semibold text-gray-700">Full Name</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-indigo-200"
                placeholder="Enter your name"
              />
            </div>

            <div>
              <label className="text-sm font-semibold text-gray-700">Phone</label>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="mt-1 w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-indigo-200"
                placeholder="Enter phone number"
              />
            </div>

            <div>
              <label className="text-sm font-semibold text-gray-700">Email</label>
              <input
                value={profile.email || ""}
                disabled
                className="mt-1 w-full border rounded-xl px-4 py-3 bg-gray-100 text-gray-500"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => navigate("/my-bookings")}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl border font-semibold hover:bg-gray-50"
            >
              View My Bookings
            </button>

            <button
              onClick={handleSave}
              disabled={saving}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold disabled:opacity-60"
            >
              {saving ? "Saving..." : "Save Changes"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
