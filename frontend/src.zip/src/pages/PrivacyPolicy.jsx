import React from "react";
import { useNavigate } from "react-router-dom";

export default function PrivacyPolicy() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto bg-white border rounded-3xl p-6 shadow-sm">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-extrabold text-gray-900">Privacy Policy</h1>
            <p className="text-gray-600 mt-1">
              How we collect, use, and protect your data.
            </p>
          </div>
          <button
            onClick={() => navigate(-1)}
            className="px-4 py-2 rounded-xl border font-semibold hover:bg-gray-50"
          >
            Back
          </button>
        </div>

        <div className="mt-6 space-y-4 text-gray-700 leading-relaxed">
          <div className="border rounded-2xl p-4 bg-gray-50">
            <p className="font-bold text-gray-900">1) Data we collect</p>
            <p className="text-sm text-gray-600 mt-1">
              Name, email, phone, address, and booking details to provide service.
            </p>
          </div>

          <div className="border rounded-2xl p-4 bg-gray-50">
            <p className="font-bold text-gray-900">2) How we use it</p>
            <p className="text-sm text-gray-600 mt-1">
              To create bookings, contact you, and improve service quality.
            </p>
          </div>

          <div className="border rounded-2xl p-4 bg-gray-50">
            <p className="font-bold text-gray-900">3) Security</p>
            <p className="text-sm text-gray-600 mt-1">
              We store only necessary data and protect access using best practices.
            </p>
          </div>

          <p className="text-sm text-gray-500">
            Need help? Contact: support@servicefinder.com
          </p>
        </div>
      </div>
    </div>
  );
}
