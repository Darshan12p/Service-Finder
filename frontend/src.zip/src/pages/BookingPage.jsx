import React, { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  getServiceByIdApi,
  createBookingApi,
  getUserAddressesApi,
  addUserAddressApi,
} from "../services/api";

import PackageModal from "../components/PackageModal";
import AddressPickerModal from "../components/AddressPickerModal";

import {
  MapPin,
  CalendarDays,
  Clock,
  CreditCard,
  BadgeCheck,
  ShieldCheck,
  Home,
  Plus,
  Receipt,
  ArrowLeft,
  CheckCircle2,
  PhoneCall,
} from "lucide-react";

/* ---------- date helpers ---------- */
function pad2(n) {
  return String(n).padStart(2, "0");
}
function toYMDLocal(date) {
  const y = date.getFullYear();
  const m = pad2(date.getMonth() + 1);
  const d = pad2(date.getDate());
  return `${y}-${m}-${d}`;
}
function getNextDays(count = 3) {
  const out = [];
  const now = new Date();
  for (let i = 0; i < count; i++) {
    const d = new Date(now);
    d.setDate(now.getDate() + i);
    out.push(d);
  }
  return out;
}
function dayLabel(dateObj, index) {
  if (index === 0) return "Today";
  if (index === 1) return "Tomorrow";
  return dateObj.toLocaleDateString(undefined, { weekday: "long" });
}
function niceDate(dateObj) {
  return dateObj.toLocaleDateString(undefined, {
    day: "2-digit",
    month: "short",
  });
}

/* ---------- helpers ---------- */
function normalizeText(v = "") {
  return String(v).trim().toLowerCase().replace(/\s+/g, " ");
}
function uniqAddresses(list = []) {
  const map = new Map();
  for (const a of list) {
    const key = `${normalizeText(a?.label)}|${normalizeText(a?.line1)}`;
    if (!map.has(key)) map.set(key, a);
  }
  return Array.from(map.values());
}
function splitAddress(line1 = "") {
  const parts = String(line1)
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  if (parts.length <= 1) return { head: line1, tail: "" };

  return {
    head: parts.slice(0, 2).join(", "),
    tail: parts.slice(2).join(", "),
  };
}

function statusPill(done, doneText = "Selected", pendingText = "Pending") {
  return done
    ? "bg-green-50 text-green-700 border-green-200"
    : "bg-gray-50 text-gray-600 border-gray-200";
}

function cardClass(active) {
  return active
    ? "border-indigo-600 bg-indigo-50 ring-2 ring-indigo-100 shadow-sm"
    : "border-gray-200 bg-white hover:bg-gray-50 hover:border-gray-300";
}

export default function BookingPage() {
  const navigate = useNavigate();
  const location = useLocation();

  const state = location.state || {};
  const serviceId = state?.serviceId;

  const [selectedPkg, setSelectedPkg] = useState(state?.selectedPkg || null);
  const [service, setService] = useState(null);
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(false);

  const [addressList, setAddressList] = useState([]);
  const [address, setAddress] = useState(null);

  const [slot, setSlot] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState("Cash");

  const [pkgOpen, setPkgOpen] = useState(false);
  const [addrPickerOpen, setAddrPickerOpen] = useState(false);
  const [creating, setCreating] = useState(false);

  const user = JSON.parse(localStorage.getItem("user") || "null");

  useEffect(() => {
    if (state?.selectedPkg) setSelectedPkg(state.selectedPkg);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state?.selectedPkg]);

  const dateOptions = useMemo(() => getNextDays(3), []);
  const timeOptions = useMemo(
    () => [
      "09:00 AM",
      "11:00 AM",
      "01:00 PM",
      "03:00 PM",
      "05:30 PM",
      "07:30 PM",
    ],
    [],
  );

  /* load service */
  useEffect(() => {
    if (!serviceId) return;

    (async () => {
      try {
        setLoading(true);
        const sRes = await getServiceByIdApi(serviceId);
        const svc = sRes?.data?.service;
        setService(svc || null);

        const pkgs = svc?.packages || [];
        setPackages(Array.isArray(pkgs) ? pkgs : []);
      } catch (e) {
        console.log(e);
        setService(null);
        setPackages([]);
      } finally {
        setLoading(false);
      }
    })();
  }, [serviceId]);

  const refreshAddresses = async () => {
    if (!user?._id) return [];

    try {
      const res = await getUserAddressesApi(user._id);
      const clean = uniqAddresses(res.data.addresses || []);
      setAddressList(clean);

      if (address) {
        const stillThere = clean.find(
          (a) =>
            normalizeText(a?.label) === normalizeText(address?.label) &&
            normalizeText(a?.line1) === normalizeText(address?.line1),
        );
        if (!stillThere) setAddress(null);
      }

      return clean;
    } catch {
      setAddressList([]);
      return [];
    }
  };

  useEffect(() => {
    refreshAddresses();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?._id]);

  const price = useMemo(
    () => Number(selectedPkg?.price || selectedPkg?.packagePrice || 0),
    [selectedPkg],
  );
  const taxes = useMemo(() => +(price * 0.05).toFixed(2), [price]);
  const total = useMemo(() => +(price + taxes).toFixed(2), [price, taxes]);

  const canBook =
    !!user?._id &&
    !!selectedPkg?.name &&
    !!address?.line1 &&
    !!slot?.date &&
    !!slot?.time &&
    !!paymentMethod;

  const stepDone = {
    pkg: !!selectedPkg?.name,
    addr: !!address?.line1,
    slot: !!slot?.date && !!slot?.time,
    pay: !!paymentMethod,
  };

  const createBooking = async () => {
    if (!canBook || creating) return;

    try {
      setCreating(true);

      const payload = {
        userId: user._id,
        customerName: user?.name || user?.fullName || "Customer",
        customerEmail: user?.email || "",
        phone: user?.phone || "",
        serviceId,

        packageName: selectedPkg.name,
        packagePrice: Number(selectedPkg.price || 0),
        durationMins: Number(selectedPkg.durationMins || 0),

        address,
        slot,
        paymentMethod,
      };

      const res = await createBookingApi(payload);
      const booking = res?.data?.booking;
      const bookingId = booking?._id;

      if (!bookingId) {
        alert("Booking created but bookingId not found");
        return;
      }

      navigate("/booking/confirmed", { state: { booking } });
    } catch (e) {
      console.log("Create booking failed:", e);
      alert(e?.response?.data?.message || "Booking failed. Please try again.");
    } finally {
      setCreating(false);
    }
  };

  if (!serviceId) {
    return (
      <div className="min-h-screen bg-gray-50 grid place-items-center p-6">
        <div className="w-full max-w-md rounded-3xl border bg-white p-8 shadow-sm">
          <p className="text-xl font-extrabold text-gray-900">
            ServiceId missing
          </p>
          <p className="mt-2 text-gray-600">
            Go back and select a service again.
          </p>
          <button
            onClick={() => navigate("/services")}
            className="mt-5 w-full rounded-2xl bg-indigo-600 py-3 font-bold text-white hover:bg-indigo-700"
          >
            Go to Services
          </button>
        </div>
      </div>
    );
  }

  const serviceImage = (() => {
    const raw = service?.imageUrl || service?.image || service?.thumbnail || "";
    if (!raw) return "";
    return raw.startsWith("http") ? raw : `http://localhost:5000${raw}`;
  })();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-white pb-24 lg:pb-8">
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-10 lg:py-8">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="flex items-center gap-2 text-sm font-semibold text-indigo-700">
              <ShieldCheck size={16} />
              Verified Experts • Secure Booking
            </p>
            <h1 className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Confirm your booking
            </h1>
            <p className="mt-2 text-sm font-semibold text-gray-600 sm:text-base">
              Service:{" "}
              <span className="font-extrabold text-gray-900">
                {service?.title || "Service"}
              </span>
            </p>
          </div>

          <button
            onClick={() => navigate(-1)}
            className="inline-flex items-center gap-2 rounded-2xl border border-gray-200 bg-white px-5 py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-50"
          >
            <ArrowLeft size={16} />
            Back
          </button>
        </div>

        {/* Progress */}
        <div className="mt-6 rounded-3xl border border-gray-200 bg-white p-4 shadow-sm">
          <div className="grid grid-cols-4 gap-2 text-center">
            {[
              { no: 1, label: "Package", done: stepDone.pkg },
              { no: 2, label: "Address", done: stepDone.addr },
              { no: 3, label: "Slot", done: stepDone.slot },
              { no: 4, label: "Payment", done: stepDone.pay },
            ].map((step) => (
              <div key={step.no} className="flex flex-col items-center gap-2">
                <div
                  className={`grid h-9 w-9 place-items-center rounded-full border text-sm font-extrabold ${
                    step.done
                      ? "border-indigo-600 bg-indigo-600 text-white"
                      : "border-gray-300 bg-white text-gray-500"
                  }`}
                >
                  {step.done ? <CheckCircle2 size={18} /> : step.no}
                </div>
                <p
                  className={`text-[11px] font-bold sm:text-sm ${
                    step.done ? "text-indigo-700" : "text-gray-500"
                  }`}
                >
                  {step.label}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Optional service image */}
        {serviceImage ? (
          <div className="mt-6 overflow-hidden rounded-[28px] border border-gray-200 bg-white shadow-sm">
            <div className="grid lg:grid-cols-[1.2fr_.8fr] items-stretch">
              <div className="overflow-hidden">
                <img
                  src={serviceImage}
                  alt={service?.title || "Service"}
                  className="w-full h-[220px] sm:h-[260px] lg:h-[300px] object-cover object-center"
                  loading="eager"
                />
              </div>

              <div className="hidden lg:flex flex-col justify-center bg-gradient-to-br from-indigo-50 to-white p-8">
                <p className="text-sm font-semibold text-indigo-600">
                  Selected Service
                </p>
                <h2 className="mt-2 text-2xl font-extrabold text-gray-900">
                  {service?.title || "Service"}
                </h2>
                <p className="mt-3 text-sm text-gray-600 leading-6">
                  Book verified professionals with transparent pricing, easy
                  scheduling, and secure service at your doorstep.
                </p>

                <div className="mt-5 flex flex-wrap gap-2">
                  
                </div>
              </div>
            </div>
          </div>
        ) : null}

        {/* Main layout */}
        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Left */}
          <div className="space-y-5 lg:col-span-2">
            {/* Package */}
            <div className="overflow-hidden rounded-3xl border border-gray-200 bg-white shadow-sm">
              <div className="flex items-start justify-between gap-4 border-b p-5 sm:p-6">
                <div className="flex items-start gap-3">
                  <div className="grid h-11 w-11 place-items-center rounded-2xl border bg-indigo-50">
                    <BadgeCheck className="text-indigo-600" size={20} />
                  </div>
                  <div>
                    <p className="font-extrabold text-gray-900">1) Package</p>
                    <p className="text-sm text-gray-600">
                      Choose the best plan for your needs.
                    </p>
                  </div>
                </div>

                <span
                  className={`rounded-full border px-3 py-1 text-xs font-bold ${statusPill(
                    stepDone.pkg,
                  )}`}
                >
                  {stepDone.pkg ? "Selected" : "Pending"}
                </span>
              </div>

              <div className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
                <div>
                  {selectedPkg ? (
                    <>
                      <p className="text-lg font-extrabold text-gray-900">
                        {selectedPkg.name} • ₹{Number(selectedPkg.price || 0)}
                      </p>
                      <p className="mt-1 text-sm text-gray-600">
                        Duration: {selectedPkg.durationMins || 60} mins
                      </p>
                    </>
                  ) : (
                    <p className="text-gray-600">No package selected.</p>
                  )}
                </div>

                <button
                  onClick={() => setPkgOpen(true)}
                  className="rounded-2xl bg-indigo-600 px-6 py-3 text-sm font-extrabold text-white hover:bg-indigo-700"
                >
                  {selectedPkg ? "Change Package" : "View Packages"}
                </button>
              </div>
            </div>

            {/* Address */}
            <div className="overflow-hidden rounded-3xl border border-gray-200 bg-white shadow-sm">
              <div className="flex items-start justify-between gap-4 border-b p-5 sm:p-6">
                <div className="flex items-start gap-3">
                  <div className="grid h-11 w-11 place-items-center rounded-2xl border bg-indigo-50">
                    <MapPin className="text-indigo-600" size={20} />
                  </div>
                  <div>
                    <p className="font-extrabold text-gray-900">2) Address</p>
                    <p className="text-sm text-gray-600">
                      Select your service location.
                    </p>
                  </div>
                </div>

                <span
                  className={`rounded-full border px-3 py-1 text-xs font-bold ${statusPill(
                    stepDone.addr,
                  )}`}
                >
                  {stepDone.addr ? "Selected" : "Pending"}
                </span>
              </div>

              <div className="p-5 sm:p-6">
                {address ? (
                  (() => {
                    const { head, tail } = splitAddress(address.line1);
                    return (
                      <div className="flex items-start justify-between gap-4 rounded-2xl border border-indigo-200 bg-indigo-50/50 p-4">
                        <div>
                          <p className="flex items-center gap-2 font-extrabold text-gray-900">
                            <Home size={16} className="text-indigo-600" />
                            {address.label || "Address"}
                          </p>
                          <p className="mt-1 text-sm font-semibold text-gray-800">
                            {head}
                          </p>
                          {tail ? (
                            <p className="mt-1 text-xs text-gray-600">{tail}</p>
                          ) : null}
                          {address?.pincode ? (
                            <p className="mt-1 text-xs text-gray-500">
                              Pincode: {address.pincode}
                            </p>
                          ) : null}
                        </div>

                        <button
                          onClick={() => setAddrPickerOpen(true)}
                          className="shrink-0 rounded-xl border border-gray-200 bg-white px-4 py-2 text-sm font-bold hover:bg-gray-50"
                        >
                          Change
                        </button>
                      </div>
                    );
                  })()
                ) : (
                  <div className="rounded-2xl border border-dashed border-gray-300 bg-gray-50 p-4 text-gray-600">
                    No address selected.
                  </div>
                )}

                <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {addressList.map((a, i) => {
                    const active =
                      normalizeText(address?.label) ===
                        normalizeText(a?.label) &&
                      normalizeText(address?.line1) === normalizeText(a?.line1);

                    const { head, tail } = splitAddress(a?.line1 || "");

                    return (
                      <button
                        key={`${a?.label || "addr"}-${a?.line1 || i}`}
                        onClick={() => setAddress(a)}
                        className={`text-left rounded-2xl border p-4 transition-all ${cardClass(
                          active,
                        )}`}
                      >
                        <p className="flex items-center gap-2 font-extrabold text-gray-900">
                          <MapPin
                            size={16}
                            className={
                              active ? "text-indigo-600" : "text-gray-500"
                            }
                          />
                          {a.label || "Home"}
                        </p>

                        <p className="mt-2 text-sm font-semibold text-gray-800">
                          {head}
                        </p>
                        {tail ? (
                          <p className="mt-1 text-xs text-gray-600">{tail}</p>
                        ) : null}
                        {a?.pincode ? (
                          <p className="mt-2 text-xs text-gray-500">
                            Pincode: {a.pincode}
                          </p>
                        ) : null}
                      </button>
                    );
                  })}
                </div>

                <div className="mt-4 flex flex-wrap gap-3">
                  <button
                    onClick={async () => {
                      const line1 = prompt(
                        "Enter address (House, Road, Area, City - Pincode)",
                      );
                      if (!line1) return;

                      const r = await addUserAddressApi(user._id, {
                        label: "Home",
                        line1,
                        source: "manual",
                      });

                      const clean = uniqAddresses(r.data.addresses || []);
                      setAddressList(clean);

                      const latest = clean[clean.length - 1];
                      if (latest) setAddress(latest);
                    }}
                    className="inline-flex items-center gap-2 rounded-2xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-extrabold text-gray-800 hover:bg-gray-50"
                  >
                    <Plus size={16} />
                    Add Address
                  </button>

                  <button
                    onClick={() => setAddrPickerOpen(true)}
                    className="inline-flex items-center gap-2 rounded-2xl bg-indigo-600 px-4 py-2.5 text-sm font-extrabold text-white hover:bg-indigo-700"
                  >
                    <MapPin size={16} />
                    Use Live Location
                  </button>
                </div>
              </div>
            </div>

            {/* Slot */}
            <div className="overflow-hidden rounded-3xl border border-gray-200 bg-white shadow-sm">
              <div className="flex items-start justify-between gap-4 border-b p-5 sm:p-6">
                <div className="flex items-start gap-3">
                  <div className="grid h-11 w-11 place-items-center rounded-2xl border bg-indigo-50">
                    <CalendarDays className="text-indigo-600" size={20} />
                  </div>
                  <div>
                    <p className="font-extrabold text-gray-900">3) Slot</p>
                    <p className="text-sm text-gray-600">
                      Pick a day and time.
                    </p>
                  </div>
                </div>

                <span
                  className={`rounded-full border px-3 py-1 text-xs font-bold ${statusPill(
                    stepDone.slot,
                  )}`}
                >
                  {stepDone.slot ? "Selected" : "Pending"}
                </span>
              </div>

              <div className="p-5 sm:p-6">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  {dateOptions.map((dObj, idx) => {
                    const ymd = toYMDLocal(dObj);
                    const active = slot?.date === ymd;

                    return (
                      <button
                        key={ymd}
                        onClick={() =>
                          setSlot((prev) => ({ ...(prev || {}), date: ymd }))
                        }
                        className={`rounded-2xl border p-4 text-left transition-all ${cardClass(
                          active,
                        )}`}
                      >
                        <p
                          className={`text-sm font-extrabold ${
                            active ? "text-indigo-700" : "text-gray-900"
                          }`}
                        >
                          {dayLabel(dObj, idx)}
                        </p>
                        <p className="mt-1 text-sm text-gray-600">
                          {niceDate(dObj)}
                        </p>
                      </button>
                    );
                  })}
                </div>

                <div className="mt-5">
                  <p className="flex items-center gap-2 text-sm font-extrabold text-gray-900">
                    <Clock size={16} className="text-indigo-600" />
                    Time
                  </p>

                  <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
                    {timeOptions.map((t) => {
                      const active = slot?.time === t;
                      const disabled = !slot?.date;

                      return (
                        <button
                          key={t}
                          disabled={disabled}
                          onClick={() =>
                            setSlot((prev) => ({ ...(prev || {}), time: t }))
                          }
                          className={`rounded-xl border px-4 py-2.5 text-sm font-bold transition ${
                            disabled
                              ? "cursor-not-allowed bg-gray-100 text-gray-400"
                              : active
                                ? "border-indigo-600 bg-indigo-600 text-white shadow-sm"
                                : "border-gray-200 bg-white text-gray-800 hover:bg-gray-50"
                          }`}
                        >
                          {t}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* Payment */}
            <div className="overflow-hidden rounded-3xl border border-gray-200 bg-white shadow-sm">
              <div className="flex items-start justify-between gap-4 border-b p-5 sm:p-6">
                <div className="flex items-start gap-3">
                  <div className="grid h-11 w-11 place-items-center rounded-2xl border bg-indigo-50">
                    <CreditCard className="text-indigo-600" size={20} />
                  </div>
                  <div>
                    <p className="font-extrabold text-gray-900">4) Payment</p>
                    <p className="text-sm text-gray-600">
                      Choose payment method.
                    </p>
                  </div>
                </div>

                <span className="rounded-full border border-green-200 bg-green-50 px-3 py-1 text-xs font-bold text-green-700">
                  Available
                </span>
              </div>

              <div className="p-5 sm:p-6">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <button
                    onClick={() => setPaymentMethod("Cash")}
                    className={`rounded-2xl border px-5 py-4 text-left font-extrabold transition ${
                      paymentMethod === "Cash"
                        ? "border-indigo-600 bg-indigo-600 text-white"
                        : "border-gray-200 bg-white text-gray-900 hover:bg-gray-50"
                    }`}
                  >
                    Cash on Service
                    <p
                      className={`mt-1 text-xs font-medium ${
                        paymentMethod === "Cash"
                          ? "text-indigo-100"
                          : "text-gray-500"
                      }`}
                    >
                      Pay after service completion
                    </p>
                  </button>
                </div>

                <p className="mt-3 text-xs text-gray-500">
                  Later you can also add Card / UPI / Wallet.
                </p>
              </div>
            </div>

            {/* Desktop confirm */}
            <div className="hidden lg:block">
              <button
                disabled={!canBook || creating}
                onClick={createBooking}
                className={`w-full rounded-2xl py-4 text-lg font-extrabold text-white transition ${
                  canBook && !creating
                    ? "bg-indigo-600 shadow-sm hover:bg-indigo-700"
                    : "cursor-not-allowed bg-gray-300"
                }`}
              >
                {creating ? "Booking..." : "Confirm Booking"}
              </button>

              {!user?._id ? (
                <p className="mt-3 text-sm font-semibold text-red-600">
                  You must sign in before booking.
                </p>
              ) : null}
            </div>
          </div>

          {/* Right */}
          <div className="lg:col-span-1">
            <div className="space-y-4 lg:sticky lg:top-6">
              <div className="rounded-3xl border border-gray-200 bg-white p-5 shadow-sm sm:p-6">
                <div className="flex items-center justify-between gap-3">
                  <p className="flex items-center gap-2 text-lg font-extrabold text-gray-900">
                    <Receipt size={18} className="text-indigo-600" />
                    Summary
                  </p>
                  <span className="rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-xs font-bold text-indigo-700">
                    Secure
                  </span>
                </div>

                <div className="mt-5 space-y-3 text-sm">
                  <div className="flex justify-between gap-3">
                    <span className="text-gray-600">Service</span>
                    <span className="text-right font-semibold text-gray-900">
                      {service?.title || "-"}
                    </span>
                  </div>

                  <div className="flex justify-between gap-3">
                    <span className="text-gray-600">Package</span>
                    <span className="font-semibold text-gray-900">
                      {selectedPkg?.name || "-"}
                    </span>
                  </div>

                  <div className="flex justify-between gap-3">
                    <span className="text-gray-600">Slot</span>
                    <span className="text-right font-semibold text-gray-900">
                      {slot?.date
                        ? `${slot.date}${slot?.time ? ` • ${slot.time}` : ""}`
                        : "-"}
                    </span>
                  </div>

                  <div className="my-3 h-px bg-gray-100" />

                  <div className="flex justify-between">
                    <span className="text-gray-600">Price</span>
                    <span className="font-semibold text-gray-900">
                      ₹{price}
                    </span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-gray-600">Taxes (5%)</span>
                    <span className="font-semibold text-gray-900">
                      ₹{taxes}
                    </span>
                  </div>

                  <div className="mt-4 rounded-2xl border border-indigo-200 bg-indigo-50 p-4">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-gray-900">
                        Total Payable
                      </span>
                      <span className="text-2xl font-extrabold text-indigo-700">
                        ₹{total}
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 rounded-2xl border border-green-200 bg-green-50 p-4">
                    <p className="flex items-center gap-2 font-extrabold text-green-800">
                      <ShieldCheck size={16} />
                      100% Verified Partners
                    </p>
                    <p className="mt-1 text-sm text-green-700">
                      Safe booking • Trusted service • Support available
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-3xl border border-gray-200 bg-white p-5 shadow-sm sm:p-6">
                <p className="font-extrabold text-gray-900">Need help?</p>
                <div className="mt-3 flex items-center gap-3 rounded-2xl bg-gray-50 p-4">
                  <div className="grid h-10 w-10 place-items-center rounded-xl bg-indigo-50">
                    <PhoneCall size={18} className="text-indigo-600" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900">
                      +91 8866807245
                    </p>
                    <p className="text-xs text-gray-500">
                      Mon–Sat, 9 AM – 7 PM
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {!user?._id ? (
          <p className="mt-4 text-sm font-semibold text-red-600 lg:hidden">
            You must sign in before booking.
          </p>
        ) : null}
      </div>

      {/* Mobile sticky confirm */}
      <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-gray-200 bg-white/95 p-3 backdrop-blur lg:hidden">
        <div className="mx-auto flex max-w-7xl items-center gap-3">
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold text-gray-500">Total</p>
            <p className="truncate text-xl font-extrabold text-indigo-700">
              ₹{total}
            </p>
          </div>

          <button
            disabled={!canBook || creating}
            onClick={createBooking}
            className={`rounded-2xl px-5 py-3 text-sm font-extrabold text-white transition ${
              canBook && !creating
                ? "bg-indigo-600 hover:bg-indigo-700"
                : "cursor-not-allowed bg-gray-300"
            }`}
          >
            {creating ? "Booking..." : "Confirm Booking"}
          </button>
        </div>
      </div>

      {/* Package modal */}
      <PackageModal
        open={pkgOpen}
        setOpen={setPkgOpen}
        selectedService={{
          ...(service || {}),
          packages,
        }}
        redirectToBooking={false}
        onSelect={(pkg) => {
          setSelectedPkg(pkg);
          setPkgOpen(false);
        }}
      />

      {/* Address picker modal */}
      <AddressPickerModal
        open={addrPickerOpen}
        setOpen={setAddrPickerOpen}
        onConfirm={async (addrObj) => {
          const payload = {
            ...addrObj,
            label: "Current Location",
            source: "live",
            lat: addrObj?.lat ?? null,
            lng: addrObj?.lng ?? null,
          };

          const existing = addressList.find(
            (a) =>
              normalizeText(a?.label) === "current location" ||
              a?.source === "live",
          );

          if (existing) {
            const updatedList = addressList.map((a) =>
              normalizeText(a?.label) === "current location" ||
              a?.source === "live"
                ? { ...a, ...payload }
                : a,
            );

            const clean = uniqAddresses(updatedList);
            setAddressList(clean);
            setAddress({ ...existing, ...payload });
            return;
          }

          const r = await addUserAddressApi(user._id, payload);
          const clean = uniqAddresses(r.data.addresses || []);
          setAddressList(clean);

          const liveAddr =
            clean.find(
              (a) =>
                normalizeText(a?.label) === "current location" ||
                a?.source === "live",
            ) || clean[clean.length - 1];

          if (liveAddr) setAddress(liveAddr);
        }}
      />
    </div>
  );
}
