import React from "react";
import { useNavigate } from "react-router-dom";

export default function Blogs() {
  const navigate = useNavigate();

  const blogs = [
    { title: "How to choose the best plumber?", date: "2026-02-01" },
    { title: "Top home cleaning tips", date: "2026-01-20" },
    { title: "Electrical safety checklist", date: "2026-01-10" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto bg-white border rounded-3xl p-6 shadow-sm">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-extrabold text-gray-900">Blogs</h1>
            <p className="text-gray-600 mt-1">Service tips, guides, and updates</p>
          </div>
          <button
            onClick={() => navigate(-1)}
            className="px-4 py-2 rounded-xl border font-semibold hover:bg-gray-50"
          >
            Back
          </button>
        </div>

        <div className="mt-6 grid gap-4">
          {blogs.map((b) => (
            <div key={b.title} className="border rounded-2xl p-4">
              <p className="font-bold text-gray-900">{b.title}</p>
              <p className="text-sm text-gray-500 mt-1">{b.date}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
