import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
// Optional: Install lucide-react for these icons or replace with emojis
import { CheckCircle2, Calendar, CreditCard, MapPin, Package, ArrowLeft, Star, } from "lucide-react";
import { List } from "lucide-react";

export default function BookingConfirmed() {
  const navigate = useNavigate();
  const { state } = useLocation();
  const booking = state?.booking;

  if (!booking) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="bg-white border border-slate-200 rounded-3xl p-8 max-w-md w-full text-center shadow-xl shadow-slate-200/50">
          <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Package size={32} />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">No booking found</h2>
          <p className="text-slate-500 mt-2">We couldn't find any recent booking data. Please try booking again.</p>
          <button
            onClick={() => navigate("/")}
            className="mt-8 w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-2xl font-bold transition-all transform active:scale-[0.98]"
          >
            Go to Homepage
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] pb-12">
      {/* Success Header Banner */}
      <div className=" h-48 w-full absolute top-0 left-0" />
      
      <div className="relative max-w-3xl mx-auto px-6 pt-12">
        <div className="bg-white border border-slate-200 rounded-[2rem] overflow-hidden shadow-2xl shadow-indigo-100">
          
          {/* Top Section: Status & Title */}
          <div className="p-8 border-b border-slate-100 bg-gradient-to-br from-white to-slate-50/50">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="bg-green-100 p-3 rounded-2xl text-green-600">
                  <CheckCircle2 size={32} />
                </div>
                <div>
                  <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                    Booking Confirmed!
                  </h1>
                  <p className="text-slate-500 font-medium">Order ID: #{booking._id?.slice(-6).toUpperCase() || 'N/A'}</p>
                </div>
              </div>
              <span className="self-start px-4 py-1.5 rounded-full bg-green-100 text-green-700 font-bold text-xs uppercase tracking-wider border border-green-200">
                {booking.bookingStatus || "Confirmed"}
              </span>
            </div>
          </div>

          <div className="p-8">
            <div className="grid gap-4 sm:grid-cols-2">
              
              {/* Service Info */}
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                <div className="flex items-center gap-2 mb-2 text-indigo-600">
                  <Package size={18} />
                  <span className="text-xs font-bold uppercase tracking-wide">Service Detail</span>
                </div>
                <p className="font-bold text-slate-900 text-lg">
                  {booking.serviceTitle || "Service Name"}
                </p>
                <p className="text-sm text-slate-500 font-medium">
                  {booking.serviceCategory || "General"}
                </p>
              </div>

              {/* Package Info */}
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                <div className="flex items-center gap-2 mb-2 text-indigo-600">
                  <Star size={18} />
                  <span className="text-xs font-bold uppercase tracking-wide">Plan</span>
                </div>
                <p className="font-bold text-slate-900 text-lg">{booking.packageName}</p>
                <p className="text-sm text-slate-500 font-medium">
                  ₹{booking.packagePrice} • {booking.durationMins} mins
                </p>
              </div>

              {/* Slot Info */}
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                <div className="flex items-center gap-2 mb-2 text-indigo-600">
                  <Calendar size={18} />
                  <span className="text-xs font-bold uppercase tracking-wide">Schedule</span>
                </div>
                <p className="font-bold text-slate-900 text-lg">{booking?.slot?.date}</p>
                <p className="text-sm text-slate-500 font-medium">{booking?.slot?.time}</p>
              </div>

              {/* Payment Info */}
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                <div className="flex items-center gap-2 mb-2 text-indigo-600">
                  <CreditCard size={18} />
                  <span className="text-xs font-bold uppercase tracking-wide">Payment</span>
                </div>
                <p className="font-bold text-slate-900 text-lg">{booking.paymentMethod}</p>
                <p className="text-sm text-slate-500 font-medium">
                  Status: <span className={booking.paymentStatus === 'Paid' ? 'text-green-600 font-bold' : 'text-amber-600 font-bold'}>
                    {booking.paymentStatus || "Unpaid"}
                  </span>
                </p>
              </div>

              {/* Address - Full Width */}
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 sm:col-span-2">
                <div className="flex items-center gap-2 mb-2 text-indigo-600">
                  <MapPin size={18} />
                  <span className="text-xs font-bold uppercase tracking-wide">Location</span>
                </div>
                <p className="font-bold text-slate-900">
                  {booking?.address?.line1}
                </p>
                {booking?.address?.pincode && (
                  <p className="text-sm text-slate-500 font-medium">
                    Pincode: {booking.address.pincode}
                  </p>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => navigate("/")}
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl border-2 border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-colors"
              >
                <ArrowLeft size={18} />
                Home
              </button>
              
              <button
                onClick={() => navigate(`/rate/${booking._id}`)}
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-lg shadow-emerald-200 transition-all"
              >
                <Star size={18} />
                Rate Service
              </button>

              <button
                onClick={() => navigate("/my-bookings")}
                className="flex-[1.2] inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold shadow-lg shadow-indigo-200 transition-all"
              >
                <List size={18} />
                Manage Bookings
              </button>
            </div>
          </div>
        </div>
        
        <p className="text-center text-slate-400 text-sm mt-8">
          A confirmation email has been sent to your registered address.
        </p>
      </div>
    </div>
  );
}